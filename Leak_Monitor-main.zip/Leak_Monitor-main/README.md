# Leak_Monitor

## 🛠️ Technologie
Projekt wykorzystuje nowoczesny stos technologiczny zapewniający skalowalność i bezpieczeństwo:

- **Frontend:** React, TypeScript, TailwindCSS, Vite
- **Backend:** Node.js, NestJS
- **Bazy danych:**
  - **PostgreSQL:** Dane użytkowników i relacje (zarządzanie kontami).
  - **Elasticsearch:** Przechowywanie i błyskawiczne przeszukiwanie ogromnych zbiorów wycieków (500GB - 2TB).
- **Infrastruktura i inne:**
  - **Redis + BullMQ:** Asynchroniczne kolejkownie zadań (wysyłka powiadomień).
  - **Amazon SES:** System powiadomień e-mail.
  - **Docker:** Konteneryzacja środowiska bazodanowego.

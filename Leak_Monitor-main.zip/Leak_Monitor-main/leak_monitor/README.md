# LEAK MONITOR

## Struktura projektu - mniej więcej
Frontend
```text
frontend/
├── src/                                     # Główny folder z kodem źródłowym aplikacji
│   ├── App/                                 # 📂 GŁÓWNA WARSTWA APLIKACJI (Komponenty i Widoki)
│   │   ├── components/                      #
│   │   │   ├── figma/                       #   -> Pliki/komponenty pomocnicze lub referencje z makiety Figma
│   │   │   │
│   │   │   ├── tabs/                        #   📂 ZAKŁADKI PANELU GŁÓWNEGO (Widoki Dashboardu)
│   │   │   │   ├── BreachesTab.tsx          #     -> Przeglądanie globalnej bazy danych znanych wycieków
│   │   │   │   ├── EmailsTab.tsx            #     -> Zarządzanie i weryfikacja monitorowanych adresów e-mail
│   │   │   │   ├── IncidentsTab.tsx         #     -> Lista szczegółowych incydentów i powiadomień o wyciekach
│   │   │   │   ├── LoginHistoryTab.tsx      #     -> Tabela z historią logowań (Twoja nowa sekcja!)
│   │   │   │   ├── OverviewTab.tsx          #     -> Ekran główny panelu (statystyki, wykresy, podsumowanie)
│   │   │   │   └── SettingsTab.tsx          #     -> Ustawienia profilu użytkownika i konfiguracja konta
│   │   │   │
│   │   │   └── ui/                          #   📂 GŁÓWNE EKRANY INTERFEJSU (UI)
│   │   │       ├── AuthScreen.tsx           #     -> Ekran autoryzacji (Logowanie / Rejestracja użytkownika)
│   │   │       └── Dashboard.tsx            #     -> Szkielet panelu (Sidebar boczny + przełącznik zakładek)
│   │   │
│   │   └── App.tsx                          # Centralny router (steruje wyświetlaniem AuthScreen lub Dashboardu)
│   │
│   ├── styles/                              # 🎨 WARSTWA STYLÓW (Konfiguracja wyglądu i motywów)
│   │   ├── fonts.css                        #   -> Definicje i importy niestandardowych krojów pisma
│   │   ├── globals.css                      #   -> Globalne reguły CSS współdzielone w aplikacji
│   │   ├── index.css                        #   -> Główny punkt wejścia CSS (spina fonty, tailwinda i motyw)
│   │   ├── tailwind.css                     #   -> Dyrektywy i konfiguracja rdzenia Tailwind CSS v4
│   │   └── theme.css                        #   -> Definicje zmiennych i kolorów dla trybów Light/Dark Mode
│   │
│   ├── main.tsx                             # Punkt startowy Reacta (inicjalizuje aplikację w drzewie DOM)
│   └── default_shadcn_theme.css             # Kopia zapasowa lub baza domyślnego motywu komponentów Shadcn
│
├── index.html                               # Główny plik HTML, w który wstrzykiwany jest cały kod Reacta
├── postcss.config.mjs                       # Konfiguracja PostCSS (narzędzie przetwarzające kod CSS dla Tailwinda)
├── pnpm-workspace.yaml                      # Konfiguracja monorepo (jeśli frontend i backend są w jednym repozytorium)
├── package.json                             # Spis bibliotek frontendu (React, Lucide, Axios) i skrypty startowe
└── package-lock.json                        # Dokładne, zablokowane wersje zainstalowanych pakietów npm
```
Backend
```text
backend/
├── src/                                     # Główny folder z kodem źródłowym aplikacji
│   ├── entities/                            # GLOBALNE MODELE BAZODANOWE (PostgreSQL + TypeORM)
│   │   ├── email-breach-match.entity.ts     #   -> Łączy zidentyfikowany wyciek z konkretnym mailem
│   │   ├── incident.entity.ts               #   -> Przechowuje wpisy o naruszeniach bezpieczeństwa użytkownika
│   │   ├── login-history.entity.ts          #   -> Historia logowań (IP, przeglądarka, data)
│   │   ├── login-log.entity.ts              #   -> Surowe logi z prób autoryzacji (udane/nieudane)
│   │   ├── user-email.entity.ts             #   -> Tabela pośrednicząca: relacje użytkowników z mailami
│   │   └── user.entity.ts                   #   -> Dane kont użytkowników (id, email, hash hasła)
│   │
│   ├── modules/                             # MODUŁY BIZNESOWE SYSTEMU (Podział na komponenty)
│   │   ├── auth/                            # 🔐 Moduł autoryzacji i zabezpieczeń kont
│   │   │   ├── guards/                      #
│   │   │   │   └── jwt-auth.guard.ts        #   -> Strażnik: blokuje zapytania bez ważnego tokenu JWT
│   │   │   ├── strategies/                  #
│   │   │   │   └── jwt.strategy.ts          #   -> Weryfikuje podpis i poprawność klucza tokenu JWT
│   │   │   ├── strategy/                    #
│   │   │   │   ├── jwt-auth.guard.ts        #   -> (Zdublowana struktura strażnika po refaktoryzacji)
│   │   │   │   └── jwt.strategy.ts          #   -> (Zdublowana struktura strategii po refaktoryzacji)
│   │   │   ├── auth.controller.ts           #   -> Obsługuje endpointy (POST /auth/login, POST /register)
│   │   │   ├── auth.service.ts              #   -> Logika: sprawdzanie haseł, generowanie tokenów, zapis logów
│   │   │   └── auth.module.ts               #   -> Główny plik modułu, konfiguruje parametry JWT
│   │   │
│   │   ├── emails/                          # 📧 Moduł zarządzania obserwowanymi adresami
│   │   │   ├── entities/                    #
│   │   │   │   └── monitored-email.entity.ts#   -> Szczegóły obserwowanego maila (status weryfikacji)
│   │   │   ├── email.module.ts              #   -> Moduł spinający kontroler i serwis obsługi maili
│   │   │   ├── emails.controller.ts         #   -> Endpointy do dodawania, usuwania i pobierania maili
│   │   │   └── emails.service.ts            #   -> Logika dodawania adresów do radaru użytkownika
│   │   │
│   │   ├── incidents/                       # 🚨 Moduł incydentów i statystyk bezpieczeństwa
│   │   │   ├── incidents.controller.ts      #   -> Endpointy dostarczające dane do wykresów i tabel panelu
│   │   │   ├── incidents.module.ts          #   -> Moduł integrujący system powiadomień o incydentach
│   │   │   └── incidents.service.ts         #   -> Pobiera z bazy zestawienia o skompromitowanych kontach
│   │   │
│   │   ├── notifications/                   # 📨 Moduł powiadomień użytkowników (System Mailer)
│   │   │   ├── mailer.service.ts            #   -> Bezpośrednia integracja z serwerem SMTP i wysyłka maili
│   │   │   ├── notifications.module.ts      #   -> Moduł konfigurujący system wiadomości wychodzących
│   │   │   └── notifications.processor.ts   #   -> Procesor tła (BullMQ): wysyła maile asynchronicznie z kolejki
│   │   │
│   │   └── scanner/                         # 🔍 Silnik skanujący wycieki danych (Serce OSINT)
│   │       ├── scanner.module.ts            #   -> Moduł spinający procesy skanowania baz danych
│   │       ├── scanner.processor.ts         #   -> Procesor tła: przeszukuje Elasticsearch po dodaniu maila
│   │       └── scanner.service.ts           #   -> Zarządza logiką wyszukiwania dopasowań w bazach wycieków
│   │
│   ├── app.module.ts                        # Centralny moduł aplikacji (łączy bazy danych i podmoduły)
│   └── main.ts                              # Punkt startowy aplikacji (odpala serwer i konfiguruje CORS)
│
├── docker-compose.yml                       # Konfiguracja Dockera (stawia kontenery Postgres, Redis, Elasticsearch)
├── package.json                             # Lista bibliotek (NestJS, TypeORM, Bull) oraz skrypty startowe
└── package-lock.json                        # Dokładne, zablokowane wersje zainstalowanych pakietów Node.js
```
## To Do
```text
-> Settings Tab
-> Upgrade darkmode
-> Check with 'wymagania funkcjonalne'
```
## Progress
```text
- 16.05.2026: Fixed authorization problems, fixed mockData usage in frontend modules, fixed refresh problems
- 17.05.2026: Generated new databases, 'fixed' dark mode problems
- 23.05.2026: Fixed "login-history jwt authorization and endpoint issues", fixed /incidents endpoint problems :), set up elasticsearch, fixed mail adding feature
- 24.05.2026: Fixed BreachesTab to work properly with elasticsearch database
```

import json
import os


def generate_elasticsearch_jsonl(source_file, output_file):
    # 1. Sprawdzenie czy plik źródłowy istnieje
    if not os.path.exists(source_file):
        print(f"Błąd: Nie znaleziono pliku źródłowego {source_file}!")
        return

    # 2. Wczytanie danych z breaches.json
    with open(source_file, "r", encoding="utf-8") as f:
        breaches = json.load(f)

    # 3. Otwarcie pliku wyjściowego .jsonl i zapisywanie linii na bieżąco
    with open(output_file, "w", encoding="utf-8") as f:
        for breach in breaches:
            breach_id = breach["id"]

            # Linia metadanych: {"index": {"_index": "breaches", "_id": X}}
            metadata = {"index": {"_index": "breaches", "_id": breach_id}}

            # Zapisujemy linię metadanych (separatorem jest \n)
            f.write(json.dumps(metadata, ensure_ascii=False) + "\n")

            # Zapisujemy linię z właściwymi danymi wycieku
            f.write(json.dumps(breach, ensure_ascii=False) + "\n")

    print(
        f"Pomyślnie wygenerowano plik w formacie JSONL dla ES: {output_file}"
    )


# Uruchomienie skryptu
generate_elasticsearch_jsonl("breaches.json", "breaches.jsonl")
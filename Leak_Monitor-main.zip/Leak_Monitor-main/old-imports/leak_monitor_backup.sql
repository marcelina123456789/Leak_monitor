--
-- PostgreSQL database dump
--

\restrict Ns7FshaRNe3qbRMUFTLHJoTr5p0Zum4kgGIsO0IbByafbKiqQfSc51UzM1nF3hm

-- Dumped from database version 18.3 (Debian 18.3-1+b1)
-- Dumped by pg_dump version 18.3 (Debian 18.3-1+b1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: email_breach_matches; Type: TABLE; Schema: public; Owner: leak_user
--

CREATE TABLE public.email_breach_matches (
    id integer NOT NULL,
    user_email_id integer NOT NULL,
    breach_id integer NOT NULL,
    data_types_exposed character varying NOT NULL,
    risk_level integer NOT NULL,
    found_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.email_breach_matches OWNER TO leak_user;

--
-- Name: email_breach_matches_id_seq; Type: SEQUENCE; Schema: public; Owner: leak_user
--

CREATE SEQUENCE public.email_breach_matches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.email_breach_matches_id_seq OWNER TO leak_user;

--
-- Name: email_breach_matches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leak_user
--

ALTER SEQUENCE public.email_breach_matches_id_seq OWNED BY public.email_breach_matches.id;


--
-- Name: incident_reports; Type: TABLE; Schema: public; Owner: leak_user
--

CREATE TABLE public.incident_reports (
    id integer NOT NULL,
    user_id integer NOT NULL,
    title character varying NOT NULL,
    description text NOT NULL,
    status character varying DEFAULT 'open'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    resolved_at timestamp without time zone
);


ALTER TABLE public.incident_reports OWNER TO leak_user;

--
-- Name: incident_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: leak_user
--

CREATE SEQUENCE public.incident_reports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.incident_reports_id_seq OWNER TO leak_user;

--
-- Name: incident_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leak_user
--

ALTER SEQUENCE public.incident_reports_id_seq OWNED BY public.incident_reports.id;


--
-- Name: login_history; Type: TABLE; Schema: public; Owner: leak_user
--

CREATE TABLE public.login_history (
    id integer NOT NULL,
    user_id integer NOT NULL,
    ip_address character varying NOT NULL,
    user_agent character varying NOT NULL,
    login_time timestamp without time zone NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.login_history OWNER TO leak_user;

--
-- Name: login_history_id_seq; Type: SEQUENCE; Schema: public; Owner: leak_user
--

CREATE SEQUENCE public.login_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.login_history_id_seq OWNER TO leak_user;

--
-- Name: login_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leak_user
--

ALTER SEQUENCE public.login_history_id_seq OWNED BY public.login_history.id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: leak_user
--

CREATE TABLE public."user" (
    id integer NOT NULL,
    primary_email character varying NOT NULL,
    password_hash character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."user" OWNER TO leak_user;

--
-- Name: user_emails; Type: TABLE; Schema: public; Owner: leak_user
--

CREATE TABLE public.user_emails (
    id integer NOT NULL,
    email character varying NOT NULL,
    user_id integer NOT NULL,
    is_verified boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_emails OWNER TO leak_user;

--
-- Name: user_emails_id_seq; Type: SEQUENCE; Schema: public; Owner: leak_user
--

CREATE SEQUENCE public.user_emails_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_emails_id_seq OWNER TO leak_user;

--
-- Name: user_emails_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leak_user
--

ALTER SEQUENCE public.user_emails_id_seq OWNED BY public.user_emails.id;


--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: leak_user
--

CREATE SEQUENCE public.user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_id_seq OWNER TO leak_user;

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leak_user
--

ALTER SEQUENCE public.user_id_seq OWNED BY public."user".id;


--
-- Name: email_breach_matches id; Type: DEFAULT; Schema: public; Owner: leak_user
--

ALTER TABLE ONLY public.email_breach_matches ALTER COLUMN id SET DEFAULT nextval('public.email_breach_matches_id_seq'::regclass);


--
-- Name: incident_reports id; Type: DEFAULT; Schema: public; Owner: leak_user
--

ALTER TABLE ONLY public.incident_reports ALTER COLUMN id SET DEFAULT nextval('public.incident_reports_id_seq'::regclass);


--
-- Name: login_history id; Type: DEFAULT; Schema: public; Owner: leak_user
--

ALTER TABLE ONLY public.login_history ALTER COLUMN id SET DEFAULT nextval('public.login_history_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: leak_user
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Name: user_emails id; Type: DEFAULT; Schema: public; Owner: leak_user
--

ALTER TABLE ONLY public.user_emails ALTER COLUMN id SET DEFAULT nextval('public.user_emails_id_seq'::regclass);


--
-- Data for Name: email_breach_matches; Type: TABLE DATA; Schema: public; Owner: leak_user
--

COPY public.email_breach_matches (id, user_email_id, breach_id, data_types_exposed, risk_level, found_at) FROM stdin;
1	71	5	password, phone	4	1993-06-03 17:45:35.879439
2	95	315	password, phone	3	2000-06-18 22:17:33.779169
3	64	447	password, phone	1	2012-02-21 14:32:11.348469
4	9	159	password, phone	2	2011-11-24 06:55:22.444044
5	2	110	password, phone	1	2009-08-13 01:40:58.838172
6	51	33	password, phone	4	2024-12-24 06:05:14.271754
7	1	461	password, phone	3	1999-03-20 00:34:06.060196
8	37	474	password, phone	1	1972-02-06 09:33:46.576985
9	31	202	password, phone	4	2024-09-01 14:16:48.33234
10	2	425	password, phone	3	2014-11-09 05:56:43.32053
11	14	438	password, phone	5	1980-08-16 02:30:53.101686
12	78	227	password, phone	1	2018-07-07 12:48:20.154755
13	71	331	password, phone	1	1991-09-11 05:28:53.137121
14	21	79	password, phone	5	2003-06-27 06:54:18.223203
15	32	193	password, phone	1	1975-12-09 04:33:28.847931
16	16	62	password, phone	1	1989-03-29 05:03:04.117234
17	45	377	password, phone	5	1986-01-16 15:38:26.105597
18	80	94	password, phone	3	2012-01-12 09:06:07.4662
19	38	347	password, phone	1	1984-05-07 06:20:52.675839
20	57	59	password, phone	3	2009-03-17 13:47:14.867416
21	34	35	password, phone	2	1992-02-20 10:50:29.438491
22	38	103	password, phone	2	1991-04-07 21:56:21.878575
23	85	378	password, phone	3	1987-12-24 04:45:27.175385
24	20	481	password, phone	3	1988-04-11 07:55:17.323097
25	80	429	password, phone	3	1998-03-21 19:01:15.975834
26	42	394	password, phone	3	1993-08-12 18:13:45.674977
27	16	374	password, phone	5	2000-07-13 19:48:04.925188
28	7	153	password, phone	1	2013-08-20 15:54:24.913079
29	58	388	password, phone	2	1986-03-10 14:22:20.883732
30	12	444	password, phone	3	2016-03-23 16:20:45.295128
31	48	211	password, phone	4	1971-01-12 23:56:36.563458
32	9	281	password, phone	2	2024-05-18 08:13:22.394469
33	34	361	password, phone	1	1978-09-17 10:37:54.229136
34	1	102	password, phone	2	2006-02-14 10:09:07.431376
35	28	322	password, phone	1	2023-03-22 21:54:51.252908
36	93	12	password, phone	5	2024-07-02 16:02:38.114143
37	67	403	password, phone	1	1975-03-11 05:47:56.664732
38	67	167	password, phone	2	2009-12-27 22:01:19.410607
39	21	190	password, phone	4	1999-07-18 19:34:15.109563
40	44	199	password, phone	5	2009-01-21 12:43:34.294612
41	51	381	password, phone	3	2004-11-01 13:48:22.298033
42	55	419	password, phone	1	1996-04-26 08:34:34.964464
43	39	478	password, phone	1	1990-08-03 23:32:30.716292
44	3	202	password, phone	3	2020-10-13 06:25:20.291652
45	69	152	password, phone	2	2003-01-18 00:27:36.751049
46	61	94	password, phone	4	1997-01-04 00:43:03.941014
47	41	174	password, phone	1	2001-04-10 10:42:55.26764
48	26	426	password, phone	4	1974-12-08 15:10:51.908905
49	99	342	password, phone	1	1991-03-31 06:36:02.922487
50	65	28	password, phone	1	1973-08-05 07:22:47.724143
51	87	162	password, phone	2	1980-05-24 05:44:46.411117
52	88	110	password, phone	1	1986-06-23 06:17:29.903685
53	5	113	password, phone	1	2009-04-12 04:10:19.417186
54	94	290	password, phone	4	2002-05-12 05:06:31.715573
55	4	75	password, phone	5	1988-07-27 14:58:59.818759
56	97	29	password, phone	2	1987-07-29 23:01:41.417902
57	69	1	password, phone	5	2014-07-23 09:20:22.010337
58	57	24	password, phone	1	1980-05-02 03:02:30.495485
59	40	264	password, phone	2	1975-08-12 08:15:14.333855
60	63	224	password, phone	2	1974-04-15 10:39:01.419493
61	44	96	password, phone	5	1988-07-02 15:22:01.876154
62	78	321	password, phone	5	1984-10-25 22:09:31.231247
63	1	295	password, phone	4	2021-10-30 10:33:25.840553
64	27	167	password, phone	5	2016-09-22 12:27:47.262514
65	31	345	password, phone	4	2022-04-02 15:38:47.038939
66	39	468	password, phone	4	1996-06-11 08:58:19.923905
67	42	186	password, phone	5	2018-06-19 09:47:15.553212
68	91	89	password, phone	4	1971-08-09 13:25:21.148
69	55	21	password, phone	1	2000-07-13 02:16:32.931658
70	57	399	password, phone	2	1996-09-11 10:55:03.284219
71	90	342	password, phone	4	1999-04-03 12:09:33.909406
72	24	104	password, phone	5	1987-03-10 12:31:28.883855
73	7	190	password, phone	5	1972-08-18 11:02:09.49735
74	91	211	password, phone	5	2017-03-24 15:18:24.130269
75	9	147	password, phone	3	2025-11-24 23:14:36.523328
76	9	25	password, phone	1	1990-09-11 22:02:58.586015
77	51	151	password, phone	2	1991-06-03 18:33:52.774584
78	54	160	password, phone	1	1987-04-26 21:26:51.975103
79	34	423	password, phone	4	2015-05-23 10:26:38.593071
80	35	42	password, phone	3	1973-06-10 05:21:21.054087
81	52	449	password, phone	3	2018-12-25 17:50:02.771899
82	59	104	password, phone	2	1974-08-21 16:32:26.972382
83	97	179	password, phone	2	2011-05-06 19:07:47.582552
84	70	397	password, phone	1	1988-01-11 18:37:32.169641
85	18	366	password, phone	1	2011-12-18 23:52:45.588035
86	76	1	password, phone	3	1994-07-20 20:58:11.886628
87	71	425	password, phone	5	1996-11-15 04:50:53.253861
88	90	240	password, phone	3	1998-02-23 14:20:26.374701
89	69	353	password, phone	3	1990-10-10 06:35:09.015815
90	19	432	password, phone	2	2022-08-18 17:46:48.566765
91	3	208	password, phone	3	2025-06-01 17:20:27.949484
92	62	12	password, phone	3	2019-07-31 22:12:50.781719
93	63	184	password, phone	5	2004-10-21 19:59:11.221631
94	61	438	password, phone	2	2018-05-28 20:52:47.164415
95	17	222	password, phone	3	2014-01-02 17:12:34.673622
96	6	309	password, phone	4	1984-04-23 22:20:08.291033
97	35	441	password, phone	3	2006-04-18 10:15:52.357284
98	66	424	password, phone	1	1994-04-03 10:47:45.517048
99	59	9	password, phone	4	2009-05-27 12:54:58.970827
100	66	162	password, phone	2	1999-08-19 06:37:22.039316
101	49	44	password, phone	1	1976-10-26 04:27:37.721048
102	28	451	password, phone	5	2021-11-10 18:26:36.127032
103	12	150	password, phone	4	2009-08-17 15:33:04.102059
104	96	414	password, phone	5	2021-03-04 14:02:19.996575
105	6	470	password, phone	1	1989-05-30 04:27:27.736987
106	16	327	password, phone	5	1973-06-15 10:35:00.644788
107	43	193	password, phone	1	1998-02-01 12:41:54.773525
108	21	468	password, phone	5	2015-01-20 20:12:17.351996
109	31	177	password, phone	4	1971-09-17 06:16:15.990493
110	55	145	password, phone	3	2001-03-22 23:03:32.280119
111	37	41	password, phone	5	1982-09-06 17:11:13.622159
112	100	214	password, phone	2	2016-08-24 01:32:43.721511
113	84	158	password, phone	1	2006-12-27 05:27:08.82318
114	12	130	password, phone	2	2019-07-13 14:41:26.767592
115	55	498	password, phone	2	1985-11-15 03:29:01.039065
116	53	252	password, phone	3	2006-10-14 06:12:01.542607
117	67	292	password, phone	4	1992-08-12 14:29:35.927917
118	77	221	password, phone	2	2021-06-12 00:55:14.203102
119	4	385	password, phone	5	2005-06-19 11:51:53.95976
120	8	461	password, phone	3	2023-01-01 06:02:53.731704
121	52	454	password, phone	5	1997-01-01 10:00:57.309832
122	72	203	password, phone	5	2002-10-04 07:23:22.57815
123	99	339	password, phone	1	2025-08-26 07:18:12.566002
124	18	52	password, phone	4	2025-10-24 06:14:25.649569
125	48	366	password, phone	3	2013-05-14 18:48:02.288921
126	18	483	password, phone	5	1986-11-22 10:36:12.386772
127	83	118	password, phone	2	2014-12-26 02:21:56.970074
128	26	375	password, phone	4	2011-09-19 19:13:04.632633
129	79	147	password, phone	5	1983-11-29 00:21:27.196775
130	54	417	password, phone	5	2014-07-03 06:21:43.043177
131	86	51	password, phone	3	2024-06-09 08:05:02.233401
132	89	271	password, phone	3	1980-10-12 09:45:57.228469
133	98	309	password, phone	1	2010-12-20 05:14:30.013618
134	91	135	password, phone	4	1997-10-18 10:06:13.908929
135	4	326	password, phone	2	1985-10-09 17:15:29.068566
136	93	431	password, phone	1	2008-07-30 13:04:11.08027
137	33	469	password, phone	1	1983-09-28 21:57:28.373996
138	12	375	password, phone	2	1994-07-30 19:02:05.702779
139	69	377	password, phone	2	2002-08-25 03:29:26.156631
140	46	435	password, phone	4	1985-11-02 03:30:09.74382
141	12	45	password, phone	4	2001-08-05 13:55:54.65221
142	58	78	password, phone	5	1971-08-10 10:40:03.640298
143	76	130	password, phone	4	1978-12-08 22:00:22.087156
144	41	400	password, phone	5	2011-05-14 23:31:02.512664
145	70	77	password, phone	5	1993-02-22 13:37:39.792134
146	6	327	password, phone	2	1994-02-06 16:26:27.883478
147	75	482	password, phone	4	1997-02-08 09:08:22.055044
148	99	75	password, phone	2	2019-02-01 14:34:29.55779
149	28	104	password, phone	1	2006-07-04 07:13:21.48536
150	35	338	password, phone	4	1991-12-29 08:28:40.922111
151	52	89	password, phone	5	2003-04-23 10:51:09.726829
152	1	162	password, phone	5	2020-04-03 11:39:06.77726
153	13	357	password, phone	4	1995-12-10 04:27:49.371142
154	43	39	password, phone	4	2017-11-13 22:01:50.871308
155	2	465	password, phone	3	1996-10-08 23:37:43.964544
156	35	167	password, phone	1	2012-10-22 13:01:09.597636
157	65	73	password, phone	3	2004-09-29 23:21:04.534559
158	20	330	password, phone	5	2010-04-20 21:49:04.517904
159	88	154	password, phone	2	2014-02-18 23:11:54.722499
160	57	338	password, phone	5	1992-06-19 15:37:31.384476
161	94	366	password, phone	3	2000-09-02 18:33:54.249858
162	19	421	password, phone	3	1997-09-27 21:13:58.150768
163	4	50	password, phone	4	1976-09-14 07:56:50.85221
164	66	329	password, phone	4	1984-12-22 19:53:56.992662
165	60	56	password, phone	4	1989-08-29 23:33:19.911145
166	64	205	password, phone	5	1992-10-18 07:07:54.42396
167	65	30	password, phone	2	1972-11-06 16:30:04.723656
168	88	344	password, phone	3	1973-05-14 22:08:48.676942
169	95	143	password, phone	5	1985-05-02 23:03:21.061209
170	58	346	password, phone	2	2004-01-31 16:11:00.186022
171	86	156	password, phone	5	2020-02-05 01:21:50.186521
172	32	242	password, phone	4	2012-12-12 22:26:20.104264
173	25	333	password, phone	1	1986-01-15 05:50:01.837641
174	59	247	password, phone	3	2017-03-17 01:49:06.404061
175	21	390	password, phone	5	1983-12-15 11:47:57.185685
176	83	312	password, phone	2	1986-08-16 15:16:21.655624
177	39	354	password, phone	2	2002-10-19 23:14:56.085453
178	53	268	password, phone	3	2011-05-30 01:29:12.171595
179	29	391	password, phone	1	2023-11-16 23:49:22.350545
180	27	166	password, phone	5	2025-03-25 09:19:37.212694
181	79	180	password, phone	3	2016-05-05 07:27:56.182791
182	19	471	password, phone	3	1983-08-14 11:53:20.135085
183	83	97	password, phone	5	2002-03-14 19:07:47.341342
184	46	182	password, phone	5	1981-09-16 20:14:13.278205
185	64	12	password, phone	2	2018-10-06 05:14:27.799639
186	1	139	password, phone	3	2016-08-17 09:21:42.440125
187	73	395	password, phone	1	2016-02-15 12:02:34.56611
188	47	189	password, phone	2	2021-01-27 11:50:45.965399
189	91	109	password, phone	3	1984-07-14 04:21:48.405649
190	20	116	password, phone	3	1985-01-12 07:05:00.542743
191	52	486	password, phone	2	2023-11-22 10:17:26.258567
192	51	279	password, phone	2	1989-04-23 23:36:46.498331
193	74	96	password, phone	5	1970-12-10 00:57:04.955633
194	38	41	password, phone	4	2004-12-22 15:30:38.15184
195	12	493	password, phone	1	2004-06-19 09:15:29.760183
196	85	289	password, phone	4	1974-01-16 15:43:38.419098
197	34	72	password, phone	1	1984-04-21 10:06:37.81069
198	38	242	password, phone	4	2004-12-06 05:25:52.039018
199	72	404	password, phone	5	1997-07-24 18:15:50.643004
200	94	42	password, phone	1	1970-09-03 15:48:59.124501
201	47	12	password, phone	1	1991-01-20 09:01:37.177587
202	73	291	password, phone	3	2007-07-13 11:51:18.770169
203	84	456	password, phone	1	1976-04-12 22:03:02.288092
204	27	425	password, phone	5	1981-10-26 17:06:33.114831
205	92	76	password, phone	1	1988-04-27 06:02:04.229285
206	91	141	password, phone	2	2003-11-29 13:42:29.747587
207	64	203	password, phone	4	1991-07-13 12:53:42.315032
208	67	289	password, phone	4	2007-10-02 11:26:45.247284
209	5	88	password, phone	1	2014-11-27 23:13:05.752644
210	53	410	password, phone	4	2004-04-28 06:26:22.985604
211	46	186	password, phone	2	1972-11-29 20:49:28.720266
212	70	209	password, phone	5	1983-10-28 03:23:57.248158
213	45	154	password, phone	2	1988-08-22 22:27:59.213505
214	100	248	password, phone	1	2016-08-05 19:28:25.452704
215	83	318	password, phone	2	1972-01-30 12:13:45.830701
216	94	103	password, phone	2	1986-08-12 16:45:48.643611
217	64	270	password, phone	2	2000-11-23 22:25:34.445143
218	37	460	password, phone	4	2001-03-24 17:19:27.28189
219	4	438	password, phone	4	1989-09-14 18:06:45.27352
220	33	257	password, phone	4	1970-08-26 18:19:33.358675
221	48	156	password, phone	5	2017-01-25 10:28:58.487596
222	82	324	password, phone	4	1991-11-02 05:27:40.493605
223	45	256	password, phone	4	1994-10-12 21:11:42.699742
224	37	438	password, phone	2	1983-02-16 13:10:10.931654
225	52	55	password, phone	3	1999-04-08 22:26:49.267352
226	83	416	password, phone	4	2013-08-28 23:14:43.01305
227	25	221	password, phone	4	1998-12-23 21:07:42.926032
228	19	91	password, phone	2	1998-08-03 00:17:23.813385
229	23	267	password, phone	3	1982-05-26 08:06:25.352122
230	88	403	password, phone	3	1982-07-05 00:11:04.394057
231	26	22	password, phone	1	2002-07-24 00:04:32.175539
232	57	211	password, phone	2	2012-07-18 08:52:33.927217
233	4	487	password, phone	3	1979-08-07 04:55:10.975196
234	9	158	password, phone	3	1979-12-21 00:58:36.709109
235	65	377	password, phone	3	2012-10-30 09:46:17.160467
236	60	416	password, phone	1	1978-08-20 23:38:15.844362
237	4	297	password, phone	4	1974-09-17 18:51:24.679576
238	37	350	password, phone	5	1981-10-09 08:37:37.437471
239	28	81	password, phone	2	1998-05-08 18:57:54.111359
240	25	292	password, phone	1	2023-11-06 20:12:14.200112
241	34	426	password, phone	3	1978-12-08 05:51:43.410134
242	38	11	password, phone	2	1991-04-29 16:22:14.96825
243	55	250	password, phone	5	2015-05-16 19:10:19.43658
244	84	372	password, phone	5	2009-09-10 11:48:58.513191
245	93	39	password, phone	5	1998-11-21 15:39:07.995447
246	60	81	password, phone	3	1974-07-01 09:35:30.026033
247	37	329	password, phone	2	2021-05-16 10:32:03.766133
248	2	325	password, phone	5	1984-09-03 02:27:32.063592
249	79	482	password, phone	2	1983-05-13 18:14:30.080361
250	22	178	password, phone	3	1985-12-17 17:45:55.458505
251	69	332	password, phone	1	2002-02-18 16:14:40.396586
252	55	310	password, phone	3	1986-09-09 12:15:15.827925
253	57	62	password, phone	5	1973-12-21 20:44:41.668783
254	57	488	password, phone	5	2015-06-16 18:55:42.781662
255	37	199	password, phone	2	2002-02-19 00:42:05.135579
256	68	241	password, phone	1	2005-05-13 07:58:07.764336
257	27	157	password, phone	4	1995-10-23 17:48:11.156577
258	83	26	password, phone	1	2024-08-04 18:32:35.042768
259	21	355	password, phone	3	2014-11-17 02:06:13.349269
260	5	113	password, phone	5	1979-07-27 05:48:11.216302
261	48	339	password, phone	5	1998-06-22 07:37:03.358214
262	85	44	password, phone	3	1975-06-01 05:36:31.375138
263	9	446	password, phone	2	2015-09-03 01:14:44.16843
264	11	57	password, phone	2	2012-06-22 08:38:18.431853
265	3	247	password, phone	1	1980-11-17 22:53:40.334748
266	98	145	password, phone	4	2006-11-25 20:54:40.808969
267	74	214	password, phone	5	1982-11-01 15:25:59.356226
268	7	350	password, phone	3	1970-04-16 12:11:58.586544
269	87	77	password, phone	3	2018-12-23 04:17:44.301804
270	88	315	password, phone	3	2023-03-23 06:06:41.001853
271	34	46	password, phone	5	2006-06-28 14:30:10.760325
272	88	75	password, phone	4	2024-08-10 20:27:58.671701
273	68	164	password, phone	5	2003-10-13 23:53:41.978645
274	41	82	password, phone	4	1975-01-04 23:54:06.51129
275	92	90	password, phone	3	2015-05-11 18:41:50.44194
276	74	109	password, phone	5	2025-05-28 15:54:40.863951
277	66	58	password, phone	5	2025-02-13 14:18:29.354468
278	14	149	password, phone	3	2023-08-06 14:19:37.487916
279	91	25	password, phone	4	2024-08-21 16:53:04.257687
280	5	16	password, phone	2	2001-01-03 19:33:54.630514
281	42	246	password, phone	2	2024-03-09 11:01:21.493533
282	71	198	password, phone	4	2001-10-27 15:22:25.355026
283	31	284	password, phone	1	1994-01-28 12:09:51.321728
284	79	133	password, phone	5	2008-08-16 17:48:23.74239
285	20	490	password, phone	3	1999-11-27 01:44:42.328172
286	89	204	password, phone	4	2015-11-20 06:33:10.654087
287	49	420	password, phone	4	2007-03-13 17:42:41.413617
288	3	433	password, phone	2	1979-12-25 08:58:54.071128
289	92	179	password, phone	4	2014-05-26 22:29:49.377625
290	22	67	password, phone	5	2010-06-23 19:22:25.720285
291	9	213	password, phone	4	1993-08-29 15:04:50.464678
292	4	93	password, phone	4	1995-06-29 09:34:51.862083
293	48	197	password, phone	1	1992-10-06 12:36:12.286867
294	26	130	password, phone	2	2018-08-24 10:22:07.403528
295	69	482	password, phone	4	1971-08-08 06:34:20.863477
296	50	373	password, phone	3	1980-06-08 22:55:18.982548
297	54	410	password, phone	3	2002-10-18 04:50:32.541745
298	43	321	password, phone	1	2024-03-04 03:23:08.40562
299	40	367	password, phone	2	2017-07-07 11:28:34.762306
300	35	423	password, phone	2	2017-02-17 21:14:00.532457
\.


--
-- Data for Name: incident_reports; Type: TABLE DATA; Schema: public; Owner: leak_user
--

COPY public.incident_reports (id, user_id, title, description, status, created_at, resolved_at) FROM stdin;
1	7	Phishing	Report	open	1989-01-02 04:06:42.831326	\N
2	9	Phishing	Report	open	1986-11-09 03:08:21.395342	\N
3	11	Phishing	Report	open	2002-01-20 02:39:28.562169	\N
4	13	Phishing	Report	open	1974-11-06 02:38:00.692983	\N
5	14	Phishing	Report	open	2009-10-07 22:49:25.720662	\N
6	16	Phishing	Report	open	1971-03-01 21:05:01.579883	\N
7	23	Phishing	Report	open	2021-12-21 19:35:10.957114	\N
8	26	Phishing	Report	open	1997-05-11 23:56:11.098328	\N
9	38	Phishing	Report	open	2018-03-16 08:57:24.843212	\N
10	45	Phishing	Report	open	1983-12-22 01:57:36.164076	\N
11	46	Phishing	Report	open	2023-05-22 07:13:07.529564	\N
12	55	Phishing	Report	open	1973-06-06 09:18:25.845358	\N
13	57	Phishing	Report	open	2009-04-20 20:11:05.471905	\N
14	68	Phishing	Report	open	2013-03-06 04:06:35.731708	\N
15	71	Phishing	Report	open	1972-06-15 18:04:41.451757	\N
16	73	Phishing	Report	open	1980-07-10 06:39:29.84733	\N
17	76	Phishing	Report	open	2011-06-03 17:50:19.487498	\N
18	79	Phishing	Report	open	2018-03-17 16:12:46.98658	\N
19	81	Phishing	Report	open	2023-05-14 16:29:14.674868	\N
20	85	Phishing	Report	open	2002-12-17 22:21:43.804757	\N
21	94	Phishing	Report	open	1974-07-06 03:52:52.36593	\N
\.


--
-- Data for Name: login_history; Type: TABLE DATA; Schema: public; Owner: leak_user
--

COPY public.login_history (id, user_id, ip_address, user_agent, login_time, success) FROM stdin;
1	1	181.144.254.144	Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.0; Trident/3.1)	2017-06-30 16:17:49.169298	t
2	1	157.131.174.128	Mozilla/5.0 (X11; Linux i686) AppleWebKit/535.0 (KHTML, like Gecko) Chrome/58.0.842.0 Safari/535.0	1977-01-30 12:08:09.368897	t
3	1	76.39.153.23	Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_10_2; rv:1.9.2.20) Gecko/6924-02-29 14:57:02.777069 Firefox/3.8	1982-04-11 21:49:36.28874	t
4	2	49.55.224.23	Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/535.36.3 (KHTML, like Gecko) Version/4.0 Safari/535.36.3	2013-11-06 15:43:15.824899	t
5	2	59.156.175.54	Mozilla/5.0 (iPad; CPU iPad OS 16_7_7 like Mac OS X) AppleWebKit/535.0 (KHTML, like Gecko) FxiOS/9.9k1568.0 Mobile/94A542 Safari/535.0	2000-04-30 06:09:26.828789	t
6	2	171.195.140.38	Mozilla/5.0 (X11; Linux i686; rv:1.9.7.20) Gecko/4537-06-23 00:51:38.000931 Firefox/11.0	1996-03-13 04:29:40.086372	t
7	2	116.89.144.184	Opera/9.26.(X11; Linux i686; bem-ZM) Presto/2.9.174 Version/12.00	2008-06-03 10:35:28.012448	t
8	2	174.75.41.39	Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_8_0 rv:5.0; gd-GB) AppleWebKit/534.49.3 (KHTML, like Gecko) Version/5.0.5 Safari/534.49.3	2002-12-18 03:44:03.018791	t
9	3	159.126.9.237	Mozilla/5.0 (iPod; U; CPU iPhone OS 3_1 like Mac OS X; mag-IN) AppleWebKit/534.42.4 (KHTML, like Gecko) Version/3.0.5 Mobile/8B111 Safari/6534.42.4	2001-11-11 07:28:08.770406	t
10	3	135.191.120.189	Mozilla/5.0 (compatible; MSIE 8.0; Windows 98; Win 9x 4.90; Trident/4.0)	1987-03-17 08:35:57.333306	t
11	3	81.198.153.161	Opera/8.42.(X11; Linux i686; kok-IN) Presto/2.9.178 Version/10.00	2016-05-26 22:17:03.175028	t
12	4	92.108.151.31	Opera/9.92.(X11; Linux x86_64; bo-IN) Presto/2.9.169 Version/10.00	1979-01-16 13:39:58.80372	t
13	4	200.121.107.55	Mozilla/5.0 (compatible; MSIE 6.0; Windows CE; Trident/5.0)	1980-09-16 10:53:23.401344	t
14	4	75.120.133.166	Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_8_5; rv:1.9.5.20) Gecko/5206-03-23 23:58:58.827835 Firefox/3.8	1998-10-02 09:52:54.473369	t
15	4	184.54.76.132	Mozilla/5.0 (Android 4.4.3; Mobile; rv:50.0) Gecko/50.0 Firefox/50.0	2020-12-31 05:50:07.056815	t
16	5	68.125.147.161	Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_5_0) AppleWebKit/534.1 (KHTML, like Gecko) Chrome/30.0.841.0 Safari/534.1	1970-02-13 23:50:48.204148	t
17	5	45.24.39.190	Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.01; Trident/5.1)	2025-05-20 04:40:07.292844	t
18	6	90.206.123.159	Mozilla/5.0 (Android 6.0; Mobile; rv:36.0) Gecko/36.0 Firefox/36.0	2009-10-30 18:08:39.915515	t
19	6	25.184.126.69	Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 10.0; Trident/5.0)	1970-08-24 22:26:35.284995	t
20	6	120.33.239.157	Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/532.38.7 (KHTML, like Gecko) Version/4.1 Safari/532.38.7	1973-10-04 11:18:32.521576	t
21	7	39.136.215.253	Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 6.1; Trident/3.1)	2004-07-19 19:47:30.066227	t
22	7	182.170.122.186	Opera/9.32.(X11; Linux x86_64; tt-RU) Presto/2.9.182 Version/12.00	1973-06-18 08:24:58.919004	t
23	7	9.197.165.86	Opera/8.30.(X11; Linux x86_64; et-EE) Presto/2.9.166 Version/10.00	2009-01-27 14:10:15.62542	t
24	7	25.18.120.78	Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.01; Trident/5.1)	2012-06-08 07:29:46.669722	t
25	7	50.246.192.1	Mozilla/5.0 (Windows NT 5.01) AppleWebKit/534.0 (KHTML, like Gecko) Chrome/33.0.817.0 Safari/534.0	1979-03-26 16:39:18.562097	t
26	8	137.188.66.207	Mozilla/5.0 (iPad; CPU iPad OS 17_4 like Mac OS X) AppleWebKit/532.0 (KHTML, like Gecko) FxiOS/14.4r9928.0 Mobile/50F607 Safari/532.0	2013-06-04 01:48:08.086323	t
27	8	154.251.178.60	Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 6.2; Trident/4.1)	1998-10-17 06:18:58.47398	t
28	9	193.56.2.126	Opera/8.55.(Windows NT 5.2; id-ID) Presto/2.9.168 Version/12.00	1973-04-15 04:27:08.574301	t
29	9	145.107.102.21	Mozilla/5.0 (Windows 98; Win 9x 4.90) AppleWebKit/534.0 (KHTML, like Gecko) Chrome/38.0.890.0 Safari/534.0	2013-09-22 23:03:15.58547	t
30	9	150.15.228.115	Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.01; Trident/5.1)	2001-10-28 16:07:01.288827	t
31	10	11.251.11.117	Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.2; Trident/3.1)	2004-12-15 23:21:44.304081	t
32	10	21.4.111.20	Mozilla/5.0 (Windows NT 5.01; ast-ES; rv:1.9.0.20) Gecko/7605-10-15 20:23:58.819275 Firefox/3.6.8	2014-03-13 18:14:48.420035	t
33	10	152.138.204.109	Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/531.28.5 (KHTML, like Gecko) Version/4.0.4 Safari/531.28.5	1999-12-23 05:23:01.839855	t
34	10	93.189.132.14	Opera/8.33.(X11; Linux i686; my-MM) Presto/2.9.189 Version/10.00	1989-06-18 20:01:55.568825	t
35	10	196.49.169.189	Opera/9.77.(Windows NT 5.1; fa-IR) Presto/2.9.181 Version/10.00	2024-08-03 18:27:42.239151	t
36	11	91.3.205.118	Opera/8.72.(Windows NT 5.01; af-ZA) Presto/2.9.185 Version/11.00	2023-10-02 01:30:46.639836	t
37	11	94.38.126.16	Mozilla/5.0 (Android 7.0; Mobile; rv:6.0) Gecko/6.0 Firefox/6.0	2014-07-08 17:30:17.622804	t
38	11	37.74.182.210	Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 5.01; Trident/5.1)	1975-10-02 09:27:00.518444	t
39	11	139.92.223.172	Opera/9.70.(Windows 98; Win 9x 4.90; ckb-IQ) Presto/2.9.185 Version/12.00	1997-05-25 06:41:07.637803	t
40	11	98.7.62.17	Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 10.0; Trident/3.0)	1995-03-29 18:32:30.737422	t
41	12	20.104.22.158	Mozilla/5.0 (iPod; U; CPU iPhone OS 3_1 like Mac OS X; hak-TW) AppleWebKit/532.5.2 (KHTML, like Gecko) Version/3.0.5 Mobile/8B117 Safari/6532.5.2	2018-06-01 10:54:18.253921	t
42	12	120.169.140.71	Opera/9.69.(Windows NT 6.2; nb-NO) Presto/2.9.172 Version/12.00	2024-12-20 10:00:23.272925	t
43	12	212.208.190.100	Opera/9.15.(Windows NT 5.0; nso-ZA) Presto/2.9.164 Version/11.00	1980-10-11 15:48:17.066997	t
44	12	96.213.183.143	Mozilla/5.0 (iPod; U; CPU iPhone OS 3_0 like Mac OS X; cmn-TW) AppleWebKit/532.4.6 (KHTML, like Gecko) Version/3.0.5 Mobile/8B113 Safari/6532.4.6	1978-05-19 21:46:08.153116	t
45	13	182.37.237.235	Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_8_2; rv:1.9.6.20) Gecko/9898-12-17 11:06:46.563232 Firefox/3.6.5	1993-01-01 02:58:47.720274	t
46	13	83.110.212.18	Mozilla/5.0 (Macintosh; PPC Mac OS X 10_12_2 rv:4.0; az-AZ) AppleWebKit/531.27.4 (KHTML, like Gecko) Version/5.1 Safari/531.27.4	1997-12-06 21:17:02.012952	t
47	14	186.129.215.107	Opera/8.26.(Windows NT 6.1; kok-IN) Presto/2.9.163 Version/11.00	2016-10-03 15:06:21.661254	t
48	14	110.74.218.4	Mozilla/5.0 (X11; Linux x86_64; rv:1.9.5.20) Gecko/8452-03-05 17:31:14.335205 Firefox/3.8	1971-05-08 18:22:36.466156	t
49	14	97.3.44.240	Mozilla/5.0 (X11; Linux i686) AppleWebKit/536.1 (KHTML, like Gecko) Chrome/62.0.845.0 Safari/536.1	1976-12-12 01:10:15.998015	t
50	14	32.86.149.89	Mozilla/5.0 (compatible; MSIE 7.0; Windows CE; Trident/3.1)	2020-04-22 19:21:28.39197	t
51	14	60.235.78.35	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5; rv:1.9.3.20) Gecko/9201-04-13 15:31:27.213593 Firefox/11.0	1986-10-23 09:11:12.857386	t
52	15	148.174.12.161	Opera/9.81.(X11; Linux x86_64; de-AT) Presto/2.9.188 Version/11.00	1985-04-30 05:57:19.445415	t
53	15	31.129.133.150	Mozilla/5.0 (X11; Linux x86_64; rv:1.9.7.20) Gecko/7514-06-08 03:28:47.328430 Firefox/3.8	2010-08-26 23:58:37.921014	t
54	15	104.179.201.234	Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 5.2; Trident/5.1)	1990-03-15 20:44:20.632748	t
55	15	185.8.11.145	Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_7_1 rv:2.0; sq-ML) AppleWebKit/534.46.5 (KHTML, like Gecko) Version/5.0 Safari/534.46.5	2023-04-26 09:41:12.918107	t
56	15	210.82.58.151	Opera/9.28.(X11; Linux x86_64; csb-PL) Presto/2.9.186 Version/12.00	2000-01-14 14:54:11.850886	t
57	16	14.79.201.181	Opera/8.11.(X11; Linux x86_64; oc-FR) Presto/2.9.164 Version/12.00	1977-09-25 18:28:25.355968	t
58	16	153.205.246.41	Mozilla/5.0 (compatible; MSIE 7.0; Windows 95; Trident/4.1)	1973-03-27 09:14:02.53352	t
59	16	83.146.39.219	Mozilla/5.0 (Macintosh; PPC Mac OS X 10_7_6) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/36.0.858.0 Safari/532.0	2008-02-17 02:00:18.558122	t
60	16	24.149.114.107	Mozilla/5.0 (X11; Linux x86_64; rv:1.9.7.20) Gecko/2828-07-17 02:31:29.346371 Firefox/3.6.9	1981-10-05 03:13:11.014471	t
61	17	118.118.30.238	Mozilla/5.0 (Windows NT 5.2) AppleWebKit/531.0 (KHTML, like Gecko) Chrome/27.0.852.0 Safari/531.0	1998-05-27 12:10:46.384556	t
62	17	74.148.58.12	Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 6.0; Trident/3.0)	1976-06-26 19:38:29.196526	t
63	17	220.148.146.28	Mozilla/5.0 (X11; Linux i686; rv:1.9.6.20) Gecko/5092-08-20 10:35:24.632950 Firefox/3.8	2023-07-02 05:25:06.589518	t
64	17	117.20.190.205	Mozilla/5.0 (Windows NT 5.0) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/45.0.810.0 Safari/535.1	1988-03-19 07:32:11.622952	t
65	17	4.42.209.215	Opera/9.43.(Windows NT 6.1; kk-KZ) Presto/2.9.164 Version/10.00	1984-07-17 14:03:22.565507	t
66	18	141.141.30.160	Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 4.0; Trident/5.0)	1986-01-29 02:30:31.230188	t
67	18	152.221.38.133	Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/3.1)	1985-03-17 22:23:05.975757	t
68	18	129.101.31.121	Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 6.1; Trident/3.0)	2023-11-16 01:53:34.388615	t
69	19	23.132.111.24	Opera/9.77.(Windows CE; doi-IN) Presto/2.9.189 Version/12.00	2008-09-08 03:16:17.625626	t
70	19	108.1.40.248	Mozilla/5.0 (compatible; MSIE 6.0; Windows 98; Trident/4.1)	1976-02-24 18:09:32.156098	t
71	19	150.46.203.146	Mozilla/5.0 (iPod; U; CPU iPhone OS 3_0 like Mac OS X; ce-RU) AppleWebKit/534.24.7 (KHTML, like Gecko) Version/3.0.5 Mobile/8B119 Safari/6534.24.7	2022-01-22 01:37:53.853285	t
72	19	161.213.251.106	Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/533.27.6 (KHTML, like Gecko) Version/4.1 Safari/533.27.6	1984-01-23 03:23:30.746362	t
73	20	193.125.91.102	Mozilla/5.0 (iPad; CPU iPad OS 17_2_1 like Mac OS X) AppleWebKit/536.2 (KHTML, like Gecko) FxiOS/18.0f3480.0 Mobile/43Q319 Safari/536.2	1981-12-22 08:43:17.59329	t
74	20	106.34.152.226	Mozilla/5.0 (Linux; Android 4.4) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/29.0.864.0 Safari/535.1	1988-04-18 21:06:46.948731	t
75	20	78.32.77.24	Mozilla/5.0 (Windows CE; fa-IR; rv:1.9.0.20) Gecko/3736-04-04 10:19:19.120911 Firefox/3.8	1979-05-22 09:36:48.709314	t
76	21	77.154.137.46	Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.2; Trident/3.0)	2021-08-17 13:20:22.36043	t
77	21	28.122.218.170	Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 6.2; Trident/5.0)	1979-11-06 20:45:47.085041	t
78	21	174.103.137.40	Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.2; Trident/3.0)	2022-09-27 07:46:49.430746	t
79	21	68.136.62.27	Mozilla/5.0 (iPad; CPU iPad OS 17_1_1 like Mac OS X) AppleWebKit/535.2 (KHTML, like Gecko) FxiOS/18.0w7215.0 Mobile/61O763 Safari/535.2	2023-12-11 08:56:13.571563	t
80	22	133.11.247.138	Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 10.0; Trident/3.0)	2005-08-26 02:38:17.03902	t
81	22	12.96.69.135	Mozilla/5.0 (Windows NT 5.2) AppleWebKit/534.0 (KHTML, like Gecko) Chrome/57.0.801.0 Safari/534.0	2025-09-19 01:58:25.26237	t
82	22	165.18.157.120	Mozilla/5.0 (iPod; U; CPU iPhone OS 3_0 like Mac OS X; fr-LU) AppleWebKit/533.4.6 (KHTML, like Gecko) Version/4.0.5 Mobile/8B111 Safari/6533.4.6	1977-11-13 12:35:20.051444	t
83	22	139.112.10.18	Mozilla/5.0 (iPhone; CPU iPhone OS 7_1_2 like Mac OS X) AppleWebKit/532.0 (KHTML, like Gecko) CriOS/24.0.822.0 Mobile/56P125 Safari/532.0	2001-08-28 23:33:47.239163	t
84	22	24.41.143.59	Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_5_7 rv:5.0; hne-IN) AppleWebKit/531.40.6 (KHTML, like Gecko) Version/5.0 Safari/531.40.6	1973-04-26 05:08:35.982756	t
85	23	130.113.52.128	Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_10_1) AppleWebKit/536.1 (KHTML, like Gecko) Chrome/62.0.821.0 Safari/536.1	1985-05-24 21:01:39.719193	t
86	23	70.124.76.213	Opera/9.88.(X11; Linux x86_64; hu-HU) Presto/2.9.164 Version/12.00	2024-05-23 23:16:46.094859	t
87	24	42.110.10.163	Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/3.1)	2007-02-06 14:26:17.121171	t
88	24	88.217.80.31	Opera/8.90.(Windows NT 11.0; st-ZA) Presto/2.9.167 Version/11.00	2025-04-24 22:37:37.818607	t
89	24	164.10.55.125	Mozilla/5.0 (Windows; U; Windows NT 5.01) AppleWebKit/535.45.2 (KHTML, like Gecko) Version/4.0 Safari/535.45.2	1996-04-14 18:23:58.170883	t
90	24	202.113.253.75	Mozilla/5.0 (Macintosh; PPC Mac OS X 10_8_6 rv:6.0; id-ID) AppleWebKit/534.9.1 (KHTML, like Gecko) Version/4.0 Safari/534.9.1	2013-10-02 09:51:12.840472	t
91	25	210.143.195.74	Mozilla/5.0 (Windows NT 6.1) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/25.0.810.0 Safari/532.0	1997-05-12 21:00:06.085031	t
92	25	169.146.38.17	Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 6.1; Trident/5.1)	1993-09-25 13:07:50.368793	t
93	25	66.190.137.218	Mozilla/5.0 (iPhone; CPU iPhone OS 13_5_1 like Mac OS X) AppleWebKit/535.0 (KHTML, like Gecko) FxiOS/14.8g9348.0 Mobile/66N242 Safari/535.0	1981-12-10 12:31:30.126389	t
94	26	153.204.204.166	Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 5.0; Trident/3.1)	1994-09-01 02:18:43.741241	t
95	26	79.212.76.51	Opera/8.59.(Windows 95; pl-PL) Presto/2.9.167 Version/10.00	1989-05-19 09:26:26.393604	t
96	27	220.179.151.214	Mozilla/5.0 (compatible; MSIE 5.0; Windows 98; Win 9x 4.90; Trident/3.1)	2002-08-04 05:43:43.527238	t
97	27	26.239.1.81	Mozilla/5.0 (Windows NT 11.0) AppleWebKit/536.1 (KHTML, like Gecko) Chrome/59.0.875.0 Safari/536.1	1987-05-24 11:52:43.099208	t
98	27	176.166.235.45	Mozilla/5.0 (X11; Linux i686) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/14.0.856.0 Safari/532.0	2009-08-27 15:44:27.112675	t
99	27	184.101.235.246	Mozilla/5.0 (compatible; MSIE 6.0; Windows 98; Win 9x 4.90; Trident/4.0)	1978-01-31 19:25:12.153982	t
100	27	115.79.230.229	Mozilla/5.0 (Windows NT 6.2) AppleWebKit/534.1 (KHTML, like Gecko) Chrome/46.0.856.0 Safari/534.1	2015-03-24 00:40:52.119403	t
101	28	141.254.223.84	Mozilla/5.0 (Windows 95) AppleWebKit/536.0 (KHTML, like Gecko) Chrome/21.0.862.0 Safari/536.0	1979-04-16 15:19:42.807898	t
102	28	16.81.120.63	Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 10.0; Trident/3.1)	2020-11-17 03:09:28.048185	t
103	29	126.81.218.124	Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.2; Trident/3.0)	1978-11-26 20:29:07.202235	t
104	29	65.109.70.60	Mozilla/5.0 (X11; Linux x86_64; rv:1.9.5.20) Gecko/8085-08-23 09:26:38.711853 Firefox/3.8	1983-03-06 03:34:36.297642	t
105	29	125.172.81.57	Opera/9.15.(X11; Linux i686; ce-RU) Presto/2.9.180 Version/12.00	1974-10-14 13:51:09.704393	t
106	30	223.164.138.209	Mozilla/5.0 (iPad; CPU iPad OS 6_1_6 like Mac OS X) AppleWebKit/531.2 (KHTML, like Gecko) CriOS/46.0.820.0 Mobile/50V547 Safari/531.2	1978-04-28 07:51:00.287557	t
107	30	162.117.180.53	Opera/9.35.(X11; Linux x86_64; kn-IN) Presto/2.9.190 Version/10.00	1977-01-01 23:17:39.228967	t
108	30	112.255.95.6	Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 4.0; Trident/3.0)	2019-01-31 08:41:02.936162	t
109	30	221.166.150.154	Opera/9.40.(X11; Linux i686; ur-IN) Presto/2.9.186 Version/11.00	1983-07-07 01:41:00.5372	t
110	30	57.202.53.203	Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_5_8) AppleWebKit/534.0 (KHTML, like Gecko) Chrome/40.0.807.0 Safari/534.0	2019-05-19 09:29:02.830956	t
111	31	206.157.70.87	Mozilla/5.0 (Windows NT 5.0; sk-SK; rv:1.9.1.20) Gecko/3416-11-16 15:01:04.773018 Firefox/3.6.19	1991-12-26 03:33:05.027461	t
112	31	164.236.201.79	Mozilla/5.0 (X11; Linux i686; rv:1.9.5.20) Gecko/2070-06-02 03:52:45.257380 Firefox/3.6.4	2009-12-31 21:58:15.069872	t
113	31	27.66.123.106	Mozilla/5.0 (iPod; U; CPU iPhone OS 3_2 like Mac OS X; nb-NO) AppleWebKit/531.42.4 (KHTML, like Gecko) Version/4.0.5 Mobile/8B115 Safari/6531.42.4	2019-08-22 07:13:03.167289	t
114	31	46.249.140.81	Mozilla/5.0 (iPhone; CPU iPhone OS 17_1_2 like Mac OS X) AppleWebKit/532.2 (KHTML, like Gecko) CriOS/39.0.821.0 Mobile/51F831 Safari/532.2	1999-11-30 08:22:39.376951	t
115	32	23.172.250.31	Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_8_4; rv:1.9.2.20) Gecko/2097-12-11 19:45:48.798369 Firefox/4.0	1999-03-14 13:59:41.760514	t
116	32	188.210.250.93	Mozilla/5.0 (compatible; MSIE 5.0; Windows CE; Trident/4.0)	2009-01-03 22:00:32.367068	t
117	32	70.151.79.128	Mozilla/5.0 (iPad; CPU iPad OS 17_1 like Mac OS X) AppleWebKit/535.1 (KHTML, like Gecko) FxiOS/10.5r1597.0 Mobile/82V224 Safari/535.1	1994-07-13 03:16:05.721778	t
118	33	46.55.196.212	Mozilla/5.0 (Windows; U; Windows NT 10.0) AppleWebKit/531.30.4 (KHTML, like Gecko) Version/4.0.3 Safari/531.30.4	2022-11-14 23:31:18.703996	t
119	33	10.244.81.171	Opera/8.65.(X11; Linux i686; mag-IN) Presto/2.9.170 Version/12.00	1992-02-15 01:33:07.822971	t
120	33	141.174.199.147	Mozilla/5.0 (iPod; U; CPU iPhone OS 3_2 like Mac OS X; ru-RU) AppleWebKit/532.50.4 (KHTML, like Gecko) Version/3.0.5 Mobile/8B111 Safari/6532.50.4	1977-06-27 19:42:18.962957	t
121	33	32.145.200.154	Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 5.2; Trident/3.0)	1998-11-10 18:34:07.767931	t
122	33	18.135.161.15	Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/535.47.5 (KHTML, like Gecko) Version/5.0 Safari/535.47.5	2008-11-15 15:42:57.007873	t
123	34	165.66.69.152	Opera/9.92.(Windows NT 4.0; eu-ES) Presto/2.9.173 Version/12.00	1988-02-03 23:19:31.259341	t
124	34	183.167.100.134	Opera/9.59.(X11; Linux i686; ak-GH) Presto/2.9.172 Version/12.00	1994-03-11 04:26:18.62249	t
125	34	24.63.145.211	Opera/9.85.(X11; Linux i686; unm-US) Presto/2.9.171 Version/11.00	1987-07-19 14:11:16.188604	t
126	34	137.239.245.88	Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_3 rv:5.0; fo-FO) AppleWebKit/531.24.7 (KHTML, like Gecko) Version/5.0.2 Safari/531.24.7	1990-03-05 14:15:21.40402	t
127	35	207.189.199.68	Opera/9.24.(Windows 98; Win 9x 4.90; wae-CH) Presto/2.9.179 Version/10.00	2017-08-19 06:05:35.95619	t
128	35	168.121.211.104	Mozilla/5.0 (iPad; CPU iPad OS 17_2_1 like Mac OS X) AppleWebKit/531.2 (KHTML, like Gecko) CriOS/45.0.809.0 Mobile/98L693 Safari/531.2	2015-04-07 06:49:16.087719	t
129	35	180.184.90.55	Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_8_9; rv:1.9.3.20) Gecko/7205-06-25 15:47:25.997406 Firefox/3.8	1985-08-15 09:47:52.878187	t
130	35	107.67.56.109	Mozilla/5.0 (compatible; MSIE 8.0; Windows CE; Trident/5.0)	2023-01-11 03:40:29.813845	t
131	35	24.189.98.190	Mozilla/5.0 (compatible; MSIE 6.0; Windows CE; Trident/5.1)	1986-01-10 12:36:37.840412	t
132	36	203.144.106.66	Mozilla/5.0 (compatible; MSIE 5.0; Windows 98; Win 9x 4.90; Trident/4.1)	1984-02-05 19:03:05.01872	t
133	36	91.99.222.191	Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_10_7 rv:3.0; oc-FR) AppleWebKit/531.30.1 (KHTML, like Gecko) Version/5.0.4 Safari/531.30.1	1983-04-07 20:09:51.89123	t
134	36	6.53.118.128	Opera/8.61.(Windows NT 4.0; so-ET) Presto/2.9.184 Version/10.00	2023-12-01 18:41:57.075135	t
135	37	22.74.111.54	Mozilla/5.0 (Windows 95) AppleWebKit/535.2 (KHTML, like Gecko) Chrome/53.0.802.0 Safari/535.2	2022-06-18 06:30:27.680274	t
136	37	74.215.29.75	Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.2 (KHTML, like Gecko) Chrome/46.0.813.0 Safari/536.2	1984-06-08 13:18:10.745512	t
137	38	41.165.32.72	Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/5.0)	1977-09-24 19:20:30.064559	t
138	38	138.131.184.133	Mozilla/5.0 (Macintosh; PPC Mac OS X 10_8_0 rv:3.0; bo-IN) AppleWebKit/534.26.7 (KHTML, like Gecko) Version/4.1 Safari/534.26.7	2002-06-15 12:46:34.72351	t
139	38	86.188.68.179	Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/535.24.7 (KHTML, like Gecko) Version/5.0.4 Safari/535.24.7	1985-09-21 06:44:22.025977	t
140	38	2.57.221.233	Mozilla/5.0 (Windows NT 6.2) AppleWebKit/534.0 (KHTML, like Gecko) Chrome/27.0.875.0 Safari/534.0	1981-01-02 08:28:58.270694	t
141	38	223.47.158.141	Mozilla/5.0 (iPod; U; CPU iPhone OS 3_2 like Mac OS X; kn-IN) AppleWebKit/532.29.5 (KHTML, like Gecko) Version/4.0.5 Mobile/8B119 Safari/6532.29.5	2011-06-11 18:57:20.824207	t
142	39	80.93.221.1	Mozilla/5.0 (iPod; U; CPU iPhone OS 3_1 like Mac OS X; kk-KZ) AppleWebKit/533.47.1 (KHTML, like Gecko) Version/4.0.5 Mobile/8B113 Safari/6533.47.1	2003-06-24 18:33:10.963559	t
143	39	72.88.246.124	Mozilla/5.0 (iPad; CPU iPad OS 6_1_6 like Mac OS X) AppleWebKit/531.2 (KHTML, like Gecko) FxiOS/10.6t8656.0 Mobile/13B528 Safari/531.2	1985-07-15 16:06:31.373206	t
144	39	143.23.250.141	Opera/9.56.(X11; Linux x86_64; nan-TW) Presto/2.9.173 Version/11.00	1987-05-26 07:47:17.37972	t
145	40	46.239.32.120	Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_2 rv:3.0; hsb-DE) AppleWebKit/533.9.5 (KHTML, like Gecko) Version/4.1 Safari/533.9.5	2001-07-22 19:14:09.565596	t
146	40	4.183.254.41	Mozilla/5.0 (Windows; U; Windows 98) AppleWebKit/534.45.3 (KHTML, like Gecko) Version/4.0.2 Safari/534.45.3	2000-07-25 08:46:11.720019	t
147	40	34.126.77.53	Mozilla/5.0 (iPhone; CPU iPhone OS 7_1_2 like Mac OS X) AppleWebKit/536.0 (KHTML, like Gecko) CriOS/20.0.832.0 Mobile/79S078 Safari/536.0	1982-03-17 21:24:27.383567	t
148	41	126.238.243.121	Mozilla/5.0 (Windows NT 5.2; sa-IN; rv:1.9.2.20) Gecko/5452-09-07 14:26:55.812851 Firefox/3.6.19	1989-05-25 08:43:39.633756	t
149	41	39.249.184.175	Mozilla/5.0 (Windows NT 6.2; se-NO; rv:1.9.2.20) Gecko/3346-05-30 08:48:26.720932 Firefox/3.6.14	2015-03-16 01:01:28.313868	t
150	41	171.8.158.30	Mozilla/5.0 (Windows NT 6.1) AppleWebKit/533.0 (KHTML, like Gecko) Chrome/21.0.847.0 Safari/533.0	2011-11-15 15:29:33.065388	t
151	41	125.128.44.131	Mozilla/5.0 (Macintosh; PPC Mac OS X 10_10_2) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/28.0.863.0 Safari/532.2	1977-12-09 17:11:48.029009	t
152	41	8.205.119.179	Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.0; Trident/5.1)	2019-04-30 01:53:39.683895	t
153	42	42.142.248.58	Mozilla/5.0 (Android 2.1; Mobile; rv:40.0) Gecko/40.0 Firefox/40.0	2025-10-16 23:11:57.699175	t
154	42	90.222.24.188	Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 11.0; Trident/4.1)	2000-02-26 18:57:31.800621	t
155	42	105.80.139.195	Opera/9.44.(X11; Linux i686; kl-GL) Presto/2.9.160 Version/11.00	1990-07-25 03:15:25.984443	t
156	43	221.163.251.66	Mozilla/5.0 (iPad; CPU iPad OS 16_7_6 like Mac OS X) AppleWebKit/535.1 (KHTML, like Gecko) FxiOS/12.4x8486.0 Mobile/08U531 Safari/535.1	1975-12-08 15:59:11.177506	t
157	43	220.193.209.76	Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 5.0; Trident/3.0)	1970-06-28 05:26:35.638215	t
158	44	7.143.253.63	Mozilla/5.0 (iPhone; CPU iPhone OS 1_1_5 like Mac OS X) AppleWebKit/535.1 (KHTML, like Gecko) CriOS/29.0.807.0 Mobile/61O329 Safari/535.1	1974-09-08 10:10:18.992342	t
159	44	214.201.88.239	Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_4) AppleWebKit/531.1 (KHTML, like Gecko) Chrome/50.0.867.0 Safari/531.1	1975-03-30 18:33:23.712253	t
160	44	151.149.238.7	Opera/8.90.(X11; Linux i686; brx-IN) Presto/2.9.160 Version/11.00	2016-05-28 21:48:29.649359	t
161	45	222.16.244.13	Opera/8.68.(Windows NT 4.0; ak-GH) Presto/2.9.178 Version/10.00	2025-06-26 07:15:05.790976	t
162	45	164.244.149.203	Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_4 rv:3.0; lv-LV) AppleWebKit/534.3.3 (KHTML, like Gecko) Version/5.0 Safari/534.3.3	1981-04-14 02:42:18.479951	t
163	45	126.117.122.117	Mozilla/5.0 (iPad; CPU iPad OS 12_5_7 like Mac OS X) AppleWebKit/532.0 (KHTML, like Gecko) FxiOS/15.1c8293.0 Mobile/27P543 Safari/532.0	1971-01-31 22:51:21.671019	t
164	45	124.247.20.17	Opera/9.14.(X11; Linux i686; pa-PK) Presto/2.9.176 Version/11.00	1975-10-26 12:27:45.150907	t
165	45	77.38.65.156	Opera/8.66.(X11; Linux i686; th-TH) Presto/2.9.177 Version/10.00	2006-02-28 05:03:39.349107	t
166	46	167.10.203.21	Mozilla/5.0 (iPhone; CPU iPhone OS 17_1_1 like Mac OS X) AppleWebKit/535.2 (KHTML, like Gecko) FxiOS/15.8c2479.0 Mobile/94G892 Safari/535.2	2010-11-02 03:01:40.279035	t
167	46	4.112.213.175	Mozilla/5.0 (compatible; MSIE 9.0; Windows 98; Trident/4.1)	1988-01-30 09:54:28.271702	t
168	46	81.197.230.152	Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_8_8; rv:1.9.4.20) Gecko/5331-05-31 10:23:27.185242 Firefox/3.8	2023-09-27 17:28:26.76774	t
169	46	82.250.190.245	Opera/9.13.(X11; Linux i686; ln-CD) Presto/2.9.164 Version/10.00	1992-03-31 04:02:00.021114	t
170	46	145.152.40.25	Mozilla/5.0 (Windows NT 5.01) AppleWebKit/531.1 (KHTML, like Gecko) Chrome/48.0.875.0 Safari/531.1	2005-05-02 19:44:34.895704	t
171	47	192.187.144.213	Mozilla/5.0 (compatible; MSIE 7.0; Windows CE; Trident/4.1)	1987-02-03 15:13:12.392339	t
172	47	37.20.213.145	Opera/8.25.(X11; Linux x86_64; hy-AM) Presto/2.9.189 Version/12.00	1974-10-30 00:25:23.950826	t
173	47	158.153.142.42	Mozilla/5.0 (Windows; U; Windows NT 11.0) AppleWebKit/532.17.6 (KHTML, like Gecko) Version/4.0.2 Safari/532.17.6	1977-09-13 15:06:14.355618	t
174	47	44.220.188.166	Mozilla/5.0 (Windows; U; Windows NT 4.0) AppleWebKit/534.43.7 (KHTML, like Gecko) Version/5.0 Safari/534.43.7	1975-07-29 01:19:32.492749	t
175	48	91.96.133.155	Opera/8.94.(X11; Linux i686; bho-IN) Presto/2.9.170 Version/11.00	1982-12-14 03:09:18.943443	t
176	48	29.159.51.97	Opera/9.89.(Windows 98; Win 9x 4.90; mt-MT) Presto/2.9.177 Version/11.00	1988-09-21 22:08:53.497032	t
177	48	103.159.43.18	Mozilla/5.0 (iPad; CPU iPad OS 3_2_2 like Mac OS X) AppleWebKit/532.1 (KHTML, like Gecko) FxiOS/14.2m2850.0 Mobile/53P385 Safari/532.1	1983-06-07 02:40:58.608815	t
178	48	109.194.3.95	Mozilla/5.0 (Windows 98; Win 9x 4.90) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/20.0.810.0 Safari/532.0	1986-08-01 17:37:41.546716	t
179	48	113.175.109.54	Mozilla/5.0 (compatible; MSIE 7.0; Windows 98; Win 9x 4.90; Trident/3.1)	1978-11-20 00:40:31.388422	t
180	49	158.8.240.80	Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 10.0; Trident/3.1)	2002-09-25 20:19:31.809121	t
181	49	168.40.146.190	Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.2; Trident/5.1)	2008-02-05 05:22:36.496704	t
182	49	19.47.251.63	Opera/8.26.(X11; Linux x86_64; mhr-RU) Presto/2.9.188 Version/12.00	1986-05-12 20:43:09.596799	t
183	49	214.58.67.33	Opera/9.25.(Windows CE; ss-ZA) Presto/2.9.188 Version/11.00	1990-07-01 13:20:44.528734	t
184	50	80.10.226.33	Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 11.0; Trident/4.1)	1996-10-25 22:59:37.971099	t
185	50	221.175.202.218	Mozilla/5.0 (iPad; CPU iPad OS 4_3_5 like Mac OS X) AppleWebKit/531.1 (KHTML, like Gecko) CriOS/20.0.817.0 Mobile/63D423 Safari/531.1	2018-05-13 09:50:41.224036	t
186	50	16.18.123.66	Mozilla/5.0 (compatible; MSIE 5.0; Windows 98; Win 9x 4.90; Trident/5.1)	1989-09-14 19:53:58.404429	t
187	50	186.181.189.209	Opera/8.96.(X11; Linux i686; ar-SS) Presto/2.9.174 Version/12.00	1998-02-23 23:08:29.831096	t
188	51	179.204.203.140	Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.2; Trident/5.1)	1975-08-04 07:19:52.334889	t
189	51	182.34.243.115	Mozilla/5.0 (Windows; U; Windows NT 5.01) AppleWebKit/535.31.2 (KHTML, like Gecko) Version/5.0.5 Safari/535.31.2	1978-11-26 20:40:14.597308	t
190	51	185.53.50.202	Mozilla/5.0 (Windows NT 11.0) AppleWebKit/536.1 (KHTML, like Gecko) Chrome/44.0.835.0 Safari/536.1	1994-05-11 03:18:51.136294	t
191	51	84.234.109.246	Mozilla/5.0 (Windows; U; Windows 98; Win 9x 4.90) AppleWebKit/532.3.1 (KHTML, like Gecko) Version/5.0.2 Safari/532.3.1	1996-08-06 07:01:17.236684	t
192	51	129.67.201.237	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_0 rv:3.0; tr-CY) AppleWebKit/535.11.7 (KHTML, like Gecko) Version/5.0 Safari/535.11.7	1994-12-13 14:50:13.941596	t
193	52	155.100.241.209	Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 5.0; Trident/3.1)	1972-08-15 23:28:45.152212	t
194	52	144.251.66.115	Opera/9.13.(Windows NT 6.2; ro-RO) Presto/2.9.184 Version/10.00	1975-03-03 20:39:08.38016	t
195	52	145.173.56.76	Mozilla/5.0 (Android 4.4.1; Mobile; rv:36.0) Gecko/36.0 Firefox/36.0	1984-06-04 07:45:37.349386	t
196	52	14.31.112.91	Mozilla/5.0 (X11; Linux i686; rv:1.9.6.20) Gecko/2326-09-14 01:31:48.338177 Firefox/3.6.10	1987-10-01 03:43:17.258558	t
197	53	80.193.51.185	Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/3.0)	1994-04-01 19:32:08.271951	t
198	53	120.83.70.245	Mozilla/5.0 (iPod; U; CPU iPhone OS 3_0 like Mac OS X; bho-IN) AppleWebKit/531.31.4 (KHTML, like Gecko) Version/4.0.5 Mobile/8B112 Safari/6531.31.4	1992-09-13 04:02:31.858093	t
199	53	176.3.122.204	Opera/8.62.(Windows 98; sat-IN) Presto/2.9.177 Version/12.00	2026-01-21 12:54:39.082003	t
200	53	129.105.200.64	Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.2; Trident/3.0)	1985-11-23 15:28:46.567032	t
201	53	81.54.101.247	Mozilla/5.0 (Macintosh; PPC Mac OS X 10_12_7; rv:1.9.6.20) Gecko/3110-08-31 03:41:21.140907 Firefox/13.0	1990-02-21 05:52:12.941646	t
202	54	212.12.207.185	Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_12_9 rv:4.0; mn-MN) AppleWebKit/532.12.1 (KHTML, like Gecko) Version/4.0.5 Safari/532.12.1	2020-03-27 13:02:19.266352	t
203	54	149.205.152.128	Mozilla/5.0 (iPad; CPU iPad OS 11_4_1 like Mac OS X) AppleWebKit/531.0 (KHTML, like Gecko) FxiOS/16.9w0699.0 Mobile/42Z958 Safari/531.0	1994-12-13 02:15:30.605037	t
204	54	32.85.93.151	Mozilla/5.0 (X11; Linux i686) AppleWebKit/533.2 (KHTML, like Gecko) Chrome/19.0.826.0 Safari/533.2	1998-10-11 07:21:40.612437	t
205	54	129.242.145.7	Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.0; Trident/5.0)	1983-02-05 20:06:31.361659	t
206	55	166.156.101.219	Mozilla/5.0 (Windows CE) AppleWebKit/534.0 (KHTML, like Gecko) Chrome/43.0.880.0 Safari/534.0	1992-03-17 13:15:02.618357	t
207	55	192.240.134.70	Mozilla/5.0 (Windows; U; Windows NT 4.0) AppleWebKit/535.48.5 (KHTML, like Gecko) Version/5.0.1 Safari/535.48.5	1984-11-10 18:55:44.066388	t
208	55	206.233.35.0	Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_3 rv:5.0; an-ES) AppleWebKit/533.49.2 (KHTML, like Gecko) Version/5.0 Safari/533.49.2	1984-04-15 13:26:22.09744	t
209	56	9.242.104.167	Opera/9.76.(X11; Linux x86_64; kl-GL) Presto/2.9.185 Version/12.00	1977-11-01 15:49:31.275714	t
210	56	137.137.94.208	Mozilla/5.0 (compatible; MSIE 7.0; Windows CE; Trident/5.0)	1982-10-03 01:38:59.967725	t
211	56	39.135.222.177	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2 rv:4.0; bg-BG) AppleWebKit/531.6.3 (KHTML, like Gecko) Version/4.0.1 Safari/531.6.3	1974-07-22 13:10:49.104111	t
212	56	67.54.87.39	Opera/8.70.(Windows NT 4.0; ss-ZA) Presto/2.9.167 Version/11.00	1972-11-09 15:13:06.641298	t
213	56	92.190.99.188	Opera/8.46.(Windows CE; wae-CH) Presto/2.9.168 Version/11.00	2018-08-04 06:19:03.929293	t
214	57	2.111.146.49	Opera/9.94.(Windows 98; li-NL) Presto/2.9.175 Version/12.00	1989-05-27 10:45:17.151677	t
215	57	137.54.245.156	Mozilla/5.0 (compatible; MSIE 5.0; Windows CE; Trident/5.1)	2011-08-03 18:24:52.240541	t
216	57	172.42.20.206	Mozilla/5.0 (Macintosh; PPC Mac OS X 10_7_9 rv:5.0; apn-IN) AppleWebKit/531.26.1 (KHTML, like Gecko) Version/5.0.2 Safari/531.26.1	1974-01-11 02:29:43.479585	t
217	58	67.130.211.208	Mozilla/5.0 (X11; Linux i686; rv:1.9.7.20) Gecko/6553-12-01 11:29:14.365356 Firefox/3.8	2001-06-15 17:50:24.015267	t
218	58	160.61.202.148	Mozilla/5.0 (Windows; U; Windows NT 4.0) AppleWebKit/534.28.2 (KHTML, like Gecko) Version/5.1 Safari/534.28.2	2006-01-25 18:41:32.76567	t
219	58	133.204.163.32	Opera/9.34.(Windows 98; Win 9x 4.90; sd-IN) Presto/2.9.178 Version/10.00	2016-01-22 00:37:53.293463	t
220	58	222.131.172.100	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/536.0 (KHTML, like Gecko) Chrome/21.0.892.0 Safari/536.0	2000-07-09 09:33:43.392919	t
221	58	185.2.226.254	Mozilla/5.0 (iPad; CPU iPad OS 4_3_5 like Mac OS X) AppleWebKit/536.1 (KHTML, like Gecko) CriOS/27.0.875.0 Mobile/88F608 Safari/536.1	2022-10-21 12:41:38.585466	t
222	59	64.165.133.59	Mozilla/5.0 (compatible; MSIE 5.0; Windows CE; Trident/3.1)	1998-12-11 23:14:06.342419	t
223	59	5.232.223.161	Opera/9.95.(Windows NT 10.0; kn-IN) Presto/2.9.184 Version/12.00	1999-08-07 00:52:28.411345	t
224	59	133.140.213.136	Mozilla/5.0 (iPad; CPU iPad OS 11_4_1 like Mac OS X) AppleWebKit/531.0 (KHTML, like Gecko) CriOS/32.0.894.0 Mobile/54P106 Safari/531.0	2009-06-06 01:11:40.295372	t
225	60	191.187.160.29	Mozilla/5.0 (iPod; U; CPU iPhone OS 3_2 like Mac OS X; ps-AF) AppleWebKit/533.37.5 (KHTML, like Gecko) Version/3.0.5 Mobile/8B113 Safari/6533.37.5	1973-12-23 23:09:16.948042	t
226	60	112.78.80.80	Mozilla/5.0 (Windows; U; Windows NT 4.0) AppleWebKit/534.47.6 (KHTML, like Gecko) Version/4.0.4 Safari/534.47.6	1978-05-12 06:32:06.302893	t
227	60	119.101.148.165	Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_9_8; rv:1.9.6.20) Gecko/6561-06-23 14:08:45.243378 Firefox/3.8	1999-07-03 20:38:50.054453	t
228	60	93.243.103.0	Mozilla/5.0 (X11; Linux x86_64; rv:1.9.7.20) Gecko/4458-05-11 22:41:43.945343 Firefox/3.8	1973-09-30 07:06:17.48019	t
229	61	72.42.200.210	Mozilla/5.0 (Windows 98; raj-IN; rv:1.9.1.20) Gecko/2897-05-19 03:17:31.864113 Firefox/3.8	2025-03-29 20:47:26.580945	t
230	61	184.128.79.223	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/531.0 (KHTML, like Gecko) Chrome/25.0.836.0 Safari/531.0	1998-11-20 07:31:03.6175	t
231	61	206.17.132.144	Mozilla/5.0 (Macintosh; PPC Mac OS X 10_5_1) AppleWebKit/531.2 (KHTML, like Gecko) Chrome/17.0.872.0 Safari/531.2	2020-03-10 18:35:51.270346	t
232	62	53.180.146.195	Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 4.0; Trident/4.1)	1980-10-28 05:17:20.076841	t
233	62	48.17.182.5	Mozilla/5.0 (X11; Linux i686; rv:1.9.7.20) Gecko/6262-11-05 16:33:16.382416 Firefox/3.8	1978-12-20 05:03:37.550776	t
234	62	14.44.117.119	Opera/8.15.(Windows NT 6.0; bs-BA) Presto/2.9.169 Version/10.00	1986-09-22 11:18:52.35025	t
235	63	34.254.65.132	Mozilla/5.0 (Macintosh; PPC Mac OS X 10_9_4; rv:1.9.5.20) Gecko/5639-09-06 18:00:29.803223 Firefox/3.8	1975-01-14 03:24:28.595368	t
236	63	160.251.101.113	Mozilla/5.0 (Linux; Android 5.0.1) AppleWebKit/534.0 (KHTML, like Gecko) Chrome/14.0.858.0 Safari/534.0	1976-10-30 23:24:55.883679	t
237	64	93.181.120.91	Opera/8.26.(Windows 98; csb-PL) Presto/2.9.164 Version/11.00	2014-09-21 03:20:58.372959	t
238	64	183.110.29.129	Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.2; Trident/4.1)	1994-01-05 07:27:18.101338	t
239	65	217.155.241.51	Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 11.0; Trident/3.1)	2008-07-14 03:38:03.895198	t
240	65	76.92.17.51	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_2 rv:4.0; mn-MN) AppleWebKit/532.34.7 (KHTML, like Gecko) Version/5.1 Safari/532.34.7	1986-06-30 03:48:43.158261	t
241	65	71.244.91.192	Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.2; Trident/5.0)	1995-03-24 00:53:12.127199	t
242	65	142.90.48.194	Opera/8.10.(Windows NT 5.1; niu-NU) Presto/2.9.176 Version/10.00	1989-06-18 11:16:05.173674	t
243	65	130.191.109.187	Mozilla/5.0 (Macintosh; PPC Mac OS X 10_12_1) AppleWebKit/531.1 (KHTML, like Gecko) Chrome/23.0.825.0 Safari/531.1	2024-12-07 23:42:11.759993	t
244	66	96.98.177.120	Opera/9.90.(Windows 98; Win 9x 4.90; da-DK) Presto/2.9.178 Version/10.00	2005-11-23 14:43:49.077799	t
245	66	49.160.238.126	Mozilla/5.0 (Linux; Android 2.2.1) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/51.0.869.0 Safari/532.0	2004-04-14 22:25:44.918874	t
246	66	31.157.237.118	Mozilla/5.0 (iPod; U; CPU iPhone OS 3_2 like Mac OS X; tn-ZA) AppleWebKit/534.4.4 (KHTML, like Gecko) Version/4.0.5 Mobile/8B118 Safari/6534.4.4	2023-12-25 04:00:37.956111	t
247	66	86.181.3.133	Mozilla/5.0 (Android 4.4.1; Mobile; rv:13.0) Gecko/13.0 Firefox/13.0	2006-09-06 12:48:02.121753	t
248	66	113.205.233.162	Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_12_2; rv:1.9.5.20) Gecko/9067-03-25 21:00:51.181519 Firefox/3.8	2012-04-17 18:12:58.912424	t
249	67	138.43.244.69	Mozilla/5.0 (Macintosh; PPC Mac OS X 10_6_9 rv:6.0; gd-GB) AppleWebKit/534.28.7 (KHTML, like Gecko) Version/5.1 Safari/534.28.7	2000-01-07 03:24:07.834517	t
250	67	81.67.254.19	Mozilla/5.0 (Android 5.0.2; Mobile; rv:63.0) Gecko/63.0 Firefox/63.0	1985-05-29 17:11:09.76594	t
251	67	46.20.74.14	Mozilla/5.0 (Linux; Android 2.3.6) AppleWebKit/531.2 (KHTML, like Gecko) Chrome/55.0.869.0 Safari/531.2	1975-06-03 18:08:36.992511	t
252	67	74.51.115.36	Mozilla/5.0 (Windows; U; Windows NT 11.0) AppleWebKit/534.17.5 (KHTML, like Gecko) Version/4.1 Safari/534.17.5	1992-02-06 14:02:29.554304	t
253	68	99.177.18.51	Opera/8.33.(X11; Linux x86_64; de-LI) Presto/2.9.178 Version/10.00	1980-08-26 12:31:10.1666	t
254	68	20.191.176.91	Mozilla/5.0 (iPhone; CPU iPhone OS 7_1_2 like Mac OS X) AppleWebKit/532.0 (KHTML, like Gecko) FxiOS/11.7i7411.0 Mobile/68L905 Safari/532.0	1981-01-15 00:44:43.848162	t
255	68	184.142.14.87	Mozilla/5.0 (X11; Linux x86_64; rv:1.9.6.20) Gecko/8018-06-16 06:13:02.179230 Firefox/3.6.16	1971-11-29 14:30:12.892724	t
256	68	5.178.255.27	Opera/9.57.(Windows NT 6.0; wal-ET) Presto/2.9.186 Version/10.00	1986-04-11 14:17:03.479475	t
257	68	94.91.186.43	Mozilla/5.0 (Linux; Android 3.2.4) AppleWebKit/531.0 (KHTML, like Gecko) Chrome/56.0.889.0 Safari/531.0	1980-09-21 18:31:47.505038	t
258	69	106.82.175.220	Opera/9.39.(X11; Linux x86_64; doi-IN) Presto/2.9.163 Version/10.00	2007-12-16 17:05:04.083749	t
259	69	188.82.37.165	Mozilla/5.0 (X11; Linux x86_64; rv:1.9.6.20) Gecko/6222-07-19 03:40:36.834900 Firefox/3.6.15	1993-11-17 10:20:59.715377	t
260	70	154.156.252.17	Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 11.0; Trident/4.0)	2015-12-19 00:23:12.242315	t
261	70	63.201.171.167	Mozilla/5.0 (compatible; MSIE 7.0; Windows 95; Trident/5.0)	1984-07-18 14:18:12.748009	t
262	70	70.63.173.105	Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_11_1 rv:2.0; ff-SN) AppleWebKit/532.26.7 (KHTML, like Gecko) Version/4.0.5 Safari/532.26.7	1990-10-14 08:43:34.983437	t
263	70	179.14.237.84	Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.1)	2002-01-26 23:51:39.303672	t
264	71	36.48.178.229	Mozilla/5.0 (Android 2.3.7; Mobile; rv:25.0) Gecko/25.0 Firefox/25.0	1982-08-09 17:44:27.201989	t
265	71	43.209.102.249	Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_12_8 rv:6.0; mk-MK) AppleWebKit/533.42.6 (KHTML, like Gecko) Version/4.0.2 Safari/533.42.6	1994-12-14 07:18:19.144726	t
266	72	222.122.185.30	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/536.2 (KHTML, like Gecko) Chrome/32.0.861.0 Safari/536.2	2023-06-23 08:50:15.188354	t
267	72	45.74.158.246	Mozilla/5.0 (iPad; CPU iPad OS 15_8_2 like Mac OS X) AppleWebKit/533.2 (KHTML, like Gecko) CriOS/48.0.838.0 Mobile/93V130 Safari/533.2	1991-06-20 01:44:36.637725	t
268	72	86.24.152.197	Mozilla/5.0 (compatible; MSIE 7.0; Windows 98; Trident/4.1)	1994-05-28 18:21:46.946364	t
269	72	149.14.76.209	Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.2; Trident/3.1)	2016-01-06 17:54:02.024081	t
270	72	71.186.35.102	Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_9_6) AppleWebKit/531.2 (KHTML, like Gecko) Chrome/52.0.889.0 Safari/531.2	1984-10-02 09:40:25.192139	t
271	73	28.22.168.173	Mozilla/5.0 (iPod; U; CPU iPhone OS 4_2 like Mac OS X; ayc-PE) AppleWebKit/532.21.4 (KHTML, like Gecko) Version/3.0.5 Mobile/8B115 Safari/6532.21.4	2021-12-29 03:36:18.241591	t
272	73	53.161.58.92	Mozilla/5.0 (compatible; MSIE 5.0; Windows 95; Trident/4.0)	2023-03-12 04:11:30.484522	t
273	73	22.199.2.241	Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.0; Trident/3.1)	2005-11-28 01:48:07.227242	t
274	73	75.239.91.116	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/532.1 (KHTML, like Gecko) Chrome/38.0.818.0 Safari/532.1	1985-08-08 12:42:28.390422	t
275	74	40.157.1.183	Opera/9.17.(X11; Linux x86_64; eu-FR) Presto/2.9.166 Version/10.00	2008-07-30 13:34:22.080071	t
276	74	12.128.205.158	Mozilla/5.0 (iPod; U; CPU iPhone OS 3_1 like Mac OS X; nds-NL) AppleWebKit/535.49.7 (KHTML, like Gecko) Version/4.0.5 Mobile/8B119 Safari/6535.49.7	2024-07-05 10:02:17.77721	t
277	74	23.82.51.137	Mozilla/5.0 (Windows; U; Windows 98; Win 9x 4.90) AppleWebKit/533.4.5 (KHTML, like Gecko) Version/5.0.5 Safari/533.4.5	2021-04-21 01:35:52.288708	t
278	74	96.162.84.104	Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 6.0; Trident/3.0)	2003-11-05 15:18:19.485775	t
279	74	158.211.48.76	Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_9_0 rv:5.0; fil-PH) AppleWebKit/534.27.1 (KHTML, like Gecko) Version/5.0.1 Safari/534.27.1	1996-08-28 11:47:38.638463	t
280	75	169.146.60.146	Opera/8.55.(Windows NT 5.2; bg-BG) Presto/2.9.170 Version/12.00	1976-03-16 03:31:09.380372	t
281	75	55.90.124.107	Mozilla/5.0 (compatible; MSIE 5.0; Windows 98; Trident/4.1)	1996-08-21 07:09:59.048457	t
282	75	195.137.97.29	Opera/9.46.(X11; Linux i686; st-ZA) Presto/2.9.188 Version/12.00	2021-01-13 23:43:54.512017	t
283	75	219.122.10.96	Opera/8.63.(Windows NT 5.0; cv-RU) Presto/2.9.173 Version/12.00	1985-05-11 14:18:24.693268	t
284	76	97.18.106.233	Mozilla/5.0 (iPod; U; CPU iPhone OS 3_1 like Mac OS X; wo-SN) AppleWebKit/533.37.2 (KHTML, like Gecko) Version/4.0.5 Mobile/8B118 Safari/6533.37.2	1984-02-22 19:38:03.361807	t
285	76	75.93.63.247	Mozilla/5.0 (Macintosh; PPC Mac OS X 10_12_7; rv:1.9.6.20) Gecko/7382-12-08 17:32:59.190094 Firefox/3.6.7	1987-09-10 00:46:25.958268	t
286	76	197.250.233.86	Mozilla/5.0 (compatible; MSIE 8.0; Windows 95; Trident/5.1)	2025-03-31 22:41:36.424905	t
287	76	96.72.199.26	Mozilla/5.0 (Windows NT 5.0) AppleWebKit/533.2 (KHTML, like Gecko) Chrome/55.0.803.0 Safari/533.2	2011-10-03 05:29:36.248382	t
288	77	165.107.129.138	Mozilla/5.0 (X11; Linux i686) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/14.0.860.0 Safari/532.0	2002-04-12 10:07:33.593279	t
289	77	193.17.149.215	Opera/8.94.(Windows NT 6.0; gu-IN) Presto/2.9.165 Version/10.00	1995-05-29 21:33:15.079046	t
290	77	213.191.157.60	Mozilla/5.0 (Linux; Android 7.1) AppleWebKit/531.0 (KHTML, like Gecko) Chrome/40.0.877.0 Safari/531.0	1972-05-08 11:36:19.792038	t
291	77	18.24.202.163	Opera/8.55.(Windows NT 11.0; cs-CZ) Presto/2.9.183 Version/10.00	2005-06-11 17:16:15.268168	t
292	77	208.136.126.229	Mozilla/5.0 (X11; Linux i686) AppleWebKit/533.2 (KHTML, like Gecko) Chrome/26.0.809.0 Safari/533.2	1994-10-11 10:31:56.983609	t
293	78	68.88.48.18	Opera/8.27.(Windows NT 4.0; mt-MT) Presto/2.9.184 Version/10.00	2021-11-25 15:33:46.597104	t
294	78	214.140.196.186	Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/533.2 (KHTML, like Gecko) CriOS/36.0.833.0 Mobile/80I517 Safari/533.2	1982-04-27 02:20:00.747724	t
295	78	7.43.170.45	Opera/8.35.(X11; Linux i686; ff-SN) Presto/2.9.174 Version/12.00	2022-11-10 14:02:02.716605	t
296	78	42.125.34.169	Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_10_7) AppleWebKit/536.2 (KHTML, like Gecko) Chrome/33.0.828.0 Safari/536.2	2022-03-25 04:10:23.373521	t
297	79	36.154.64.134	Mozilla/5.0 (Windows CE; ur-IN; rv:1.9.1.20) Gecko/5652-01-30 06:16:55.649994 Firefox/3.8	1993-09-05 09:03:05.607292	t
298	79	164.131.136.57	Mozilla/5.0 (Linux; Android 3.2.2) AppleWebKit/533.1 (KHTML, like Gecko) Chrome/49.0.895.0 Safari/533.1	2024-08-01 23:11:57.755199	t
299	79	174.225.172.0	Opera/8.45.(X11; Linux i686; pa-PK) Presto/2.9.181 Version/10.00	2004-11-29 09:27:28.370064	t
300	79	70.38.218.95	Mozilla/5.0 (Windows NT 6.2; lij-IT; rv:1.9.2.20) Gecko/4042-06-19 06:35:42.068474 Firefox/3.8	2024-02-25 01:52:43.87096	t
301	79	184.125.200.125	Mozilla/5.0 (Android 4.2; Mobile; rv:38.0) Gecko/38.0 Firefox/38.0	1978-06-19 09:05:31.741988	t
302	80	214.69.28.18	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/533.1 (KHTML, like Gecko) Chrome/58.0.868.0 Safari/533.1	1985-01-17 16:28:23.446646	t
303	80	25.212.248.197	Mozilla/5.0 (X11; Linux i686; rv:1.9.6.20) Gecko/3136-08-16 07:28:57.939804 Firefox/14.0	1982-04-11 17:12:40.559491	t
304	80	43.77.35.165	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_4 rv:3.0; ur-IN) AppleWebKit/533.9.5 (KHTML, like Gecko) Version/5.1 Safari/533.9.5	1980-02-25 09:14:23.059672	t
305	81	206.172.222.60	Mozilla/5.0 (X11; Linux i686; rv:1.9.5.20) Gecko/2105-05-02 06:41:18.693475 Firefox/9.0	1988-05-24 11:12:41.211073	t
306	81	39.2.192.128	Mozilla/5.0 (X11; Linux i686) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/16.0.804.0 Safari/535.1	2000-02-12 12:59:04.902743	t
307	82	205.242.13.37	Mozilla/5.0 (X11; Linux i686) AppleWebKit/531.1 (KHTML, like Gecko) Chrome/59.0.803.0 Safari/531.1	1975-12-06 16:13:56.554956	t
308	82	145.11.178.98	Mozilla/5.0 (Windows 98; hr-HR; rv:1.9.2.20) Gecko/7110-06-10 18:33:09.931946 Firefox/3.6.2	1997-05-15 08:58:40.859916	t
309	82	114.134.93.55	Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 5.01; Trident/4.1)	2025-12-08 01:04:29.08138	t
310	82	132.80.161.209	Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.2; Trident/4.0)	2015-02-24 18:21:10.204709	t
311	82	206.142.226.5	Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 5.2; Trident/4.0)	2014-03-09 01:22:03.139219	t
312	83	167.172.203.158	Opera/9.54.(Windows NT 6.2; brx-IN) Presto/2.9.179 Version/11.00	1986-08-19 02:45:49.255604	t
313	83	216.110.112.168	Mozilla/5.0 (Android 4.1.2; Mobile; rv:5.0) Gecko/5.0 Firefox/5.0	1993-02-11 21:15:26.520152	t
314	83	130.135.126.181	Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.01; Trident/5.0)	1993-10-16 03:12:29.879129	t
315	83	99.91.115.4	Mozilla/5.0 (Android 4.4.3; Mobile; rv:33.0) Gecko/33.0 Firefox/33.0	1999-02-22 12:19:55.764569	t
316	83	30.163.231.112	Opera/9.11.(X11; Linux x86_64; ro-RO) Presto/2.9.178 Version/12.00	1986-03-22 03:08:29.55645	t
317	84	132.234.38.207	Mozilla/5.0 (iPod; U; CPU iPhone OS 4_0 like Mac OS X; dv-MV) AppleWebKit/535.3.5 (KHTML, like Gecko) Version/4.0.5 Mobile/8B111 Safari/6535.3.5	1990-09-10 03:52:02.111245	t
318	84	48.54.195.57	Opera/9.31.(X11; Linux x86_64; hsb-DE) Presto/2.9.163 Version/10.00	1985-04-29 05:38:43.282941	t
319	85	19.15.171.168	Opera/9.59.(Windows NT 10.0; tl-PH) Presto/2.9.185 Version/12.00	2010-11-21 02:42:23.033715	t
320	85	140.215.239.203	Mozilla/5.0 (compatible; MSIE 6.0; Windows 95; Trident/5.1)	1983-09-10 04:10:08.344518	t
321	85	208.176.71.233	Mozilla/5.0 (Windows NT 4.0; ja-JP; rv:1.9.2.20) Gecko/6355-10-12 03:48:48.105927 Firefox/15.0	1982-08-20 15:15:51.923529	t
322	86	117.103.104.98	Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_9_1 rv:6.0; bn-IN) AppleWebKit/534.34.2 (KHTML, like Gecko) Version/4.0.3 Safari/534.34.2	1973-12-15 04:19:57.075993	t
323	86	1.118.180.204	Opera/8.91.(X11; Linux i686; wal-ET) Presto/2.9.171 Version/11.00	1979-06-12 11:25:48.872776	t
324	86	149.217.118.110	Opera/9.27.(Windows NT 10.0; fr-CH) Presto/2.9.182 Version/11.00	2020-05-26 23:24:04.186179	t
325	86	45.98.71.65	Opera/9.95.(X11; Linux i686; sv-FI) Presto/2.9.182 Version/12.00	1976-07-07 03:48:07.10515	t
326	86	220.235.52.224	Mozilla/5.0 (compatible; MSIE 6.0; Windows 95; Trident/3.1)	2024-02-29 06:06:48.025641	t
327	87	76.93.39.34	Mozilla/5.0 (iPad; CPU iPad OS 17_4 like Mac OS X) AppleWebKit/534.1 (KHTML, like Gecko) CriOS/61.0.827.0 Mobile/15N751 Safari/534.1	1982-12-07 20:50:15.53327	t
328	87	213.139.231.0	Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0)	2017-01-29 20:00:16.049889	t
329	88	222.124.185.188	Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/531.11.1 (KHTML, like Gecko) Version/4.0.4 Safari/531.11.1	2017-03-28 19:48:19.717575	t
330	88	67.94.54.223	Mozilla/5.0 (Android 12; Mobile; rv:12.0) Gecko/12.0 Firefox/12.0	2001-09-10 12:41:53.803263	t
331	88	52.16.69.237	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/531.2 (KHTML, like Gecko) Chrome/37.0.838.0 Safari/531.2	2024-06-08 06:21:53.42543	t
332	88	209.144.220.203	Opera/9.90.(Windows NT 5.1; id-ID) Presto/2.9.171 Version/12.00	2013-04-21 22:16:38.086442	t
333	88	66.222.125.129	Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/531.1 (KHTML, like Gecko) CriOS/13.0.848.0 Mobile/74Z875 Safari/531.1	2010-08-27 04:58:26.218733	t
334	89	44.171.89.166	Opera/9.52.(X11; Linux x86_64; ur-IN) Presto/2.9.184 Version/11.00	2008-01-25 22:00:27.936716	t
335	89	202.72.122.63	Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 5.2; Trident/4.1)	2013-08-05 17:20:23.671648	t
336	89	198.134.138.191	Mozilla/5.0 (Windows; U; Windows 98) AppleWebKit/535.45.2 (KHTML, like Gecko) Version/4.1 Safari/535.45.2	1979-10-30 20:01:46.222233	t
337	89	37.43.197.193	Mozilla/5.0 (compatible; MSIE 8.0; Windows 98; Trident/3.0)	2008-02-18 13:39:42.913365	t
338	89	223.142.55.45	Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 6.2; Trident/3.0)	2015-06-24 14:42:43.541826	t
339	90	119.124.217.177	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_0; rv:1.9.4.20) Gecko/8951-01-31 09:09:27.779724 Firefox/3.6.19	2003-07-18 17:45:12.069315	t
340	90	19.176.130.159	Mozilla/5.0 (iPad; CPU iPad OS 2_2_1 like Mac OS X) AppleWebKit/533.1 (KHTML, like Gecko) CriOS/49.0.899.0 Mobile/34O355 Safari/533.1	1990-09-28 12:00:53.136951	t
341	91	111.180.66.115	Mozilla/5.0 (Windows NT 5.2) AppleWebKit/535.0 (KHTML, like Gecko) Chrome/56.0.899.0 Safari/535.0	2008-03-19 15:14:35.658404	t
342	91	29.53.56.255	Mozilla/5.0 (Linux; Android 5.0.2) AppleWebKit/533.0 (KHTML, like Gecko) Chrome/48.0.888.0 Safari/533.0	2015-06-10 07:55:15.563346	t
343	91	125.192.236.98	Mozilla/5.0 (iPod; U; CPU iPhone OS 3_0 like Mac OS X; tig-ER) AppleWebKit/535.41.4 (KHTML, like Gecko) Version/4.0.5 Mobile/8B116 Safari/6535.41.4	2019-12-25 01:42:59.506115	t
344	91	142.41.29.161	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_2) AppleWebKit/533.0 (KHTML, like Gecko) Chrome/59.0.885.0 Safari/533.0	2024-08-08 18:48:12.505884	t
345	91	118.101.114.190	Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 6.1; Trident/5.0)	2004-10-08 09:55:22.409394	t
346	92	163.213.49.96	Mozilla/5.0 (Windows CE) AppleWebKit/536.0 (KHTML, like Gecko) Chrome/23.0.803.0 Safari/536.0	2006-10-21 19:19:54.928548	t
347	92	165.241.113.17	Opera/8.36.(Windows NT 5.1; zh-HK) Presto/2.9.160 Version/12.00	1980-08-24 23:30:13.618773	t
348	92	149.22.143.146	Mozilla/5.0 (iPod; U; CPU iPhone OS 4_1 like Mac OS X; ti-ER) AppleWebKit/531.34.7 (KHTML, like Gecko) Version/3.0.5 Mobile/8B112 Safari/6531.34.7	2010-02-01 20:42:53.126566	t
349	93	118.69.57.62	Mozilla/5.0 (iPod; U; CPU iPhone OS 3_3 like Mac OS X; aa-ET) AppleWebKit/531.47.2 (KHTML, like Gecko) Version/3.0.5 Mobile/8B115 Safari/6531.47.2	2009-09-19 14:42:08.157219	t
350	93	161.160.238.165	Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 4.0; Trident/4.1)	2022-04-28 21:25:34.550667	t
351	94	133.136.197.14	Mozilla/5.0 (iPhone; CPU iPhone OS 3_2_2 like Mac OS X) AppleWebKit/531.1 (KHTML, like Gecko) FxiOS/11.8d5416.0 Mobile/51B423 Safari/531.1	2018-01-31 17:34:22.022021	t
352	94	135.31.44.255	Mozilla/5.0 (compatible; MSIE 6.0; Windows 98; Trident/5.1)	1995-12-25 22:30:57.615465	t
353	94	30.157.205.164	Mozilla/5.0 (iPhone; CPU iPhone OS 5_1_1 like Mac OS X) AppleWebKit/534.0 (KHTML, like Gecko) CriOS/14.0.839.0 Mobile/04D420 Safari/534.0	2008-02-28 10:59:08.021988	t
354	94	155.160.186.253	Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/4.1)	1975-07-06 01:13:28.59541	t
355	94	113.165.126.184	Mozilla/5.0 (iPod; U; CPU iPhone OS 4_0 like Mac OS X; hu-HU) AppleWebKit/531.17.6 (KHTML, like Gecko) Version/3.0.5 Mobile/8B112 Safari/6531.17.6	2008-08-11 22:46:33.567472	t
356	95	123.51.217.123	Mozilla/5.0 (iPad; CPU iPad OS 17_4 like Mac OS X) AppleWebKit/535.0 (KHTML, like Gecko) FxiOS/16.3u6599.0 Mobile/17X339 Safari/535.0	2021-06-14 12:09:07.528328	t
357	95	27.131.1.222	Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_6_1 rv:3.0; ve-ZA) AppleWebKit/531.9.4 (KHTML, like Gecko) Version/5.0 Safari/531.9.4	1983-12-27 00:27:16.49383	t
358	95	19.212.11.44	Mozilla/5.0 (iPhone; CPU iPhone OS 17_1 like Mac OS X) AppleWebKit/536.0 (KHTML, like Gecko) FxiOS/11.0q9151.0 Mobile/04J551 Safari/536.0	1983-03-16 12:43:37.000912	t
359	95	2.230.149.28	Mozilla/5.0 (compatible; MSIE 6.0; Windows 98; Win 9x 4.90; Trident/3.1)	2002-04-15 03:14:40.026425	t
360	96	170.158.139.203	Opera/8.96.(Windows NT 10.0; lb-LU) Presto/2.9.179 Version/11.00	2016-04-27 22:10:04.886714	t
361	96	155.20.133.104	Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 11.0; Trident/5.1)	1975-02-14 13:34:53.538065	t
362	96	89.34.87.49	Mozilla/5.0 (Windows NT 11.0) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/55.0.861.0 Safari/535.1	1976-10-09 19:15:00.995892	t
363	96	138.120.228.251	Mozilla/5.0 (Windows; U; Windows 95) AppleWebKit/535.29.3 (KHTML, like Gecko) Version/4.0 Safari/535.29.3	1978-10-26 12:11:17.001415	t
364	96	162.185.211.251	Mozilla/5.0 (Windows NT 5.2) AppleWebKit/536.0 (KHTML, like Gecko) Chrome/43.0.886.0 Safari/536.0	1972-06-13 11:58:13.487737	t
365	97	108.226.15.237	Opera/8.37.(Windows 98; Win 9x 4.90; pl-PL) Presto/2.9.165 Version/10.00	2010-11-03 11:08:26.30074	t
366	97	135.154.202.17	Mozilla/5.0 (Android 7.1; Mobile; rv:52.0) Gecko/52.0 Firefox/52.0	1971-05-11 04:51:20.071414	t
367	98	14.154.58.45	Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/534.3.6 (KHTML, like Gecko) Version/5.0 Safari/534.3.6	2006-03-23 07:20:37.699704	t
368	98	24.124.209.5	Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.0; Trident/3.1)	2008-01-08 03:08:53.928347	t
369	98	205.39.32.67	Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.01; Trident/3.0)	2012-09-03 18:23:54.800879	t
370	98	150.42.139.201	Mozilla/5.0 (iPad; CPU iPad OS 12_4_4 like Mac OS X) AppleWebKit/531.1 (KHTML, like Gecko) CriOS/32.0.808.0 Mobile/64U737 Safari/531.1	1972-01-18 09:28:54.582896	t
371	98	185.225.117.134	Opera/9.30.(X11; Linux x86_64; iw-IL) Presto/2.9.173 Version/12.00	2007-11-05 06:11:43.834501	t
372	99	174.2.38.86	Opera/9.62.(Windows NT 11.0; se-NO) Presto/2.9.185 Version/12.00	1982-03-07 22:42:30.748074	t
373	99	40.97.64.89	Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_11_5) AppleWebKit/533.2 (KHTML, like Gecko) Chrome/28.0.890.0 Safari/533.2	2020-05-25 00:28:10.644726	t
374	99	198.116.26.15	Opera/8.82.(X11; Linux i686; br-FR) Presto/2.9.167 Version/12.00	2000-07-16 11:29:18.053082	t
375	99	149.7.110.63	Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 6.1; Trident/5.1)	2008-06-04 08:22:48.488579	t
376	99	221.226.108.252	Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 4.0; Trident/4.0)	1980-02-24 16:14:56.551265	t
377	100	19.230.24.2	Opera/8.78.(X11; Linux x86_64; tig-ER) Presto/2.9.178 Version/11.00	2005-10-26 10:58:16.449716	t
378	100	73.133.169.50	Mozilla/5.0 (iPad; CPU iPad OS 16_7_6 like Mac OS X) AppleWebKit/536.1 (KHTML, like Gecko) FxiOS/17.5p9458.0 Mobile/80B612 Safari/536.1	2010-11-26 09:32:42.855695	t
379	100	148.217.238.219	Mozilla/5.0 (Macintosh; PPC Mac OS X 10_11_4 rv:4.0; el-CY) AppleWebKit/531.8.3 (KHTML, like Gecko) Version/5.0 Safari/531.8.3	1987-08-09 12:13:20.161397	t
380	100	200.186.47.138	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_4) AppleWebKit/536.0 (KHTML, like Gecko) Chrome/14.0.872.0 Safari/536.0	1975-08-02 13:52:50.589812	t
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: leak_user
--

COPY public."user" (id, primary_email, password_hash, is_active, created_at, updated_at) FROM stdin;
1	qmisiejuk@example.net	edd407f054e6e3f763680e322a4180a5075103dd1be06f5a798fe8cb6a23582b	t	1996-01-02 01:11:36.727526	2025-01-25 20:21:58.045511
2	tomasz22@example.org	8a13f0785997c7a5344ab8a17a53dc1a8cd77e3feb1438a69a400cb6ee52a18d	t	2023-06-03 14:32:47.859556	1989-06-08 09:07:17.721092
3	soniapawlaczek@example.org	ef3c8fa788f8191801307c63a13b0e7e8a9db3c5e738b4c0c6ba82052d0b99a7	t	2012-11-12 00:03:04.143044	1999-08-24 16:17:29.147148
4	karol21@example.com	72d472665565e01cf6987112551239d49591c99a9efedce090b8aed646776d2e	t	1998-02-06 22:45:35.657053	1981-07-16 20:52:28.246341
5	szymonstosio@example.com	518776f1365f51005a1e939f613094b7d49f9e064add4d13ea0db24c46d56d82	t	1996-09-21 12:16:39.469888	2003-04-24 06:07:18.81163
6	radoslaw95@example.net	efc74bb79caeb111e35254d3545045de88a1e90d36643a641522d6ace3d1389a	t	2013-10-29 21:51:28.235545	1999-10-16 08:36:35.357469
7	vszlapa@example.net	4740ebb5881ddbeacc14805568d7f5e69e20ff77a35de1e1d4a9a611ada1f298	t	2005-02-19 23:14:05.388367	1972-09-30 10:05:32.931762
8	powazkaadam@example.com	ab32c6c9d0575a1107800c85834ce3b69682982540be3af2763b52e2385ce3ed	t	1987-07-30 03:01:00.710948	1986-12-31 22:57:14.998029
9	marcelina00@example.com	5646431ea7ed1b5fcf8a1202281161b4b34bc4d8bc6f3492d6de160e3db59f43	t	1985-06-20 11:34:33.893948	1998-01-09 20:37:34.931482
10	zsaj@example.org	64745e16b2e42c78a0b9c993cd92fb98ae42e4f8883a3373580f46996a0ea391	t	2025-10-18 02:18:05.756304	1978-06-26 07:42:44.996733
11	rsiembab@example.net	20f903e999063fbcb90384933fbf7aa04e99fd0760e52cd8436bd846de623cde	t	2008-11-04 12:29:06.709368	1984-10-17 01:44:21.30806
12	vwielgos@example.net	945d61e6051006a75538201c063c765abefcb6bfc470241470247b2aac7d4db7	t	1988-05-21 11:39:08.861872	2016-06-16 18:30:30.719599
13	julian21@example.com	0347380dd2ba188505c9300b9b4fb398dde6d1f3685e256bb1136e0f8c94c91d	t	2023-09-03 14:37:44.460763	1976-03-05 10:11:20.00114
14	lukasz99@example.com	ff961519e7294a87edee306eb38ec0188f576edf1f2f262c5ea436df2918c164	t	1986-10-26 22:13:35.802214	1991-03-19 14:13:41.888056
15	adriankocwin@example.com	4bd0082917f382049f795c28b657394ce2085bc3418e10c85157f109c3cfbafc	t	2023-02-11 20:36:14.157903	2013-04-22 04:37:02.336725
16	vjezyk@example.net	fd527c3e1035f802ba97168977e7de068e1468831f53c874fc2ea112ef6e0358	t	1996-11-17 00:45:48.414356	2017-04-18 03:52:24.19215
17	marcin43@example.net	edea41a4a8bc7ef9ada5e44c9daf6b7ad804f0f3c3af39ec6691040278f1ab46	t	2010-02-03 22:52:41.875723	2019-08-16 00:13:50.251937
18	ikolsut@example.net	b56fa5933b303f1f99ea01500daef8ea86f59223e55e951551d0ec8f46d2959b	t	1982-03-03 19:14:02.677806	2025-04-11 14:07:43.063878
19	kubanekrobert@example.org	26888843bd9f097c36a16dcedd7880de2c33ac3d19c97d70869faaf99f55afdc	t	1997-09-27 14:57:48.983151	1982-11-22 17:24:46.954412
20	ebaster@example.com	c6ce9ed0c4bdbe6f1712ab17412f9963bc4827c2a1fb749886b159c3ad2ab29c	t	2009-10-15 14:08:05.940868	2008-04-14 07:02:27.902173
21	dagmarasadej@example.com	29455b17422ba720ae6935726bbc03068207bff35b386d4601407fea59fba95a	t	1973-04-16 06:57:31.82616	2016-07-26 12:16:35.977207
22	fraczewelina@example.com	7551a4e9b5f3dca5933556cb49efe0db5d3f36c53ebbdee7316d36354573b3a1	t	2025-01-12 23:37:33.392251	1994-11-23 04:06:24.801918
23	mgabara@example.org	ebb10fc3a812c01942116ad25d56d729c751e6d27018709a08e1fb2abcd52da8	t	1992-03-16 23:19:36.489789	1994-06-18 03:37:43.835295
24	kudrabruno@example.com	4b10966c090b76df6bb31c28764a74dc107413ed3fc6462e33d640aa93e2b186	t	1977-11-02 21:17:35.741629	2003-12-19 17:12:16.611913
25	mieszkoberes@example.com	3e69b8235ed3d126792f9ad0c6a5169bd39b7d4a2b908097753797e6d53584fa	t	2015-06-01 03:09:26.306074	2013-01-26 21:26:47.938834
26	nela48@example.net	af5a1873a896d910529e3e4afcb29d856643aeca3f60352385dc599f99865ac7	t	2013-04-09 06:06:03.285141	1994-03-16 21:55:12.130783
27	pawellepak@example.net	17732fa5e419f0b9b7f25021b4e81cb8de9eb5805a399dea42e6ea850f38de74	t	1979-05-30 11:40:03.454595	2007-10-11 00:25:20.599857
28	olafmaciejczuk@example.com	f9488c45da7a1b4cec80cd1a3d28b8b38d59e4005458abdc41fcb389786fb668	t	1981-05-31 05:20:25.128301	2003-10-29 19:12:23.122067
29	francadam@example.org	f5fe2f929767db65aa8dcb0caadb52a8f5def95eb1a340d30c95db1703e1dc6c	t	2001-04-05 19:02:00.486288	1979-06-15 19:10:50.289214
30	roza33@example.org	3d266275b155709d44373ceaf66a947300c7068edfcb6e307888ff094c9504ef	t	1974-05-19 08:16:53.935866	1983-05-11 13:50:07.741515
31	nmajzner@example.org	4892cb5ccc5961b87c297f7b516a72b5a519a32b836943855f6bd21bec742040	t	2015-08-12 19:39:51.488279	2006-11-12 01:56:15.577209
32	gaja99@example.org	fc9e18d7af4ce77b871159196d4314e77ccc51c00e7b7a3ed1ff888ae8c8b954	t	2025-09-15 01:05:30.382829	2015-10-30 18:05:21.292576
33	rkaczmar@example.net	1d777adb12b45221394880450c47f68f33b3023b218e7b6198e73344d3d15180	t	1989-03-23 18:01:44.282	2004-02-16 01:25:12.241055
34	jduszkiewicz@example.org	2c7e271ddfb55b71f6da493e6b1727d692191e35d8ea2b1979018950dd8b1fe2	t	2026-02-17 18:45:47.807773	2017-04-17 20:53:38.458772
35	filip80@example.net	45aed276b60e6a0e6805380589b2a9b3367147c1b0813c877048ad894b5889ac	t	1973-01-02 17:53:12.132297	2002-02-27 04:37:41.801947
36	ukolek@example.org	d84f9cc273f538322908661ed582c9ee0f1aa19ef5b219de48408a1fa3b56603	t	2004-03-18 12:32:12.381824	1983-08-15 00:30:18.146415
37	nwiertel@example.org	43bb703ded9a61c1535a8f8515c9ef8327ee154959e7f073edbf84810a49304e	t	2017-06-06 03:49:03.979732	2025-11-16 08:27:34.377393
38	anita15@example.org	0decdacb5d4190a0b2f3b754bb46d0a883ab8900cabbafa9d1a1295c2398b5ae	t	2009-02-23 16:42:45.022192	1991-03-20 13:34:37.123818
39	liwiajewula@example.org	06402b5731344898069982bad3cfd3c8288e31195ab69c8e31b4c83fac81f082	t	1974-12-27 18:54:04.491241	1973-03-05 21:22:50.310506
40	kajetanbres@example.net	b7efb053686e8a633af30cc70891335bb46cccef8a61ee8888bc65c269decbfe	t	1972-12-17 03:08:16.342268	1996-10-14 16:57:34.159163
41	urszulagalik@example.com	64b909c685bdcfd689bcd1759c1df6acf77950c4b4ce8e2e990b54a77cbe1d9f	t	2000-09-21 03:25:36.50441	2024-04-29 19:11:39.928025
42	konstanty08@example.org	5508fe51eab49f6277e8af0be1861e39a5c89b2ee3fb4cc2efb6a248507ca326	t	1984-07-09 14:21:08.774677	2017-03-05 17:04:05.649509
43	ksawery93@example.com	eb4343edd99efc03a722df76551be8d1e7c5b6abc5e208b476c77cd5fa908e55	t	2003-01-26 16:51:25.38218	1997-06-04 17:50:59.137368
44	blanka10@example.org	1bf292b87d8cb3b17e8060b37622b53f128fc9c0573282119ee7cc539c31352f	t	2012-05-09 01:35:13.579513	2016-04-04 05:00:55.488685
45	jerzy96@example.com	610a70cae93ca5a272e1153913437f1cb83383d20ae85cb7e5a33b581700bf99	t	1971-01-20 17:12:38.82028	1975-02-25 14:39:18.811248
46	dorota82@example.com	be5ca2af8387b4367004d2b1eeea97dc84143c042e7910e91129b9d59ad1c16d	t	2000-11-17 23:41:10.582925	1999-09-06 04:04:32.108101
47	rozumwiktor@example.org	c16cd2aea8f1a3923e41c21fa4530e43dc603755e4e724ea9c4ae4490df43db1	t	1978-09-22 07:54:04.559879	2001-11-16 20:15:14.743893
48	ekopczyk@example.com	660c92e5d615a617fc81cd75c78b92cd5e138abd50231dc934b961e86ed680dc	t	1974-12-22 04:43:18.739709	2023-02-02 00:53:29.524234
49	mateuszgiersz@example.org	c52ba5f935d00988f2d4e9c77066e0813f09193b97f5de6375ae2447c0527a75	t	1972-08-06 02:45:37.624004	2002-07-17 03:36:06.743227
50	tadeusz26@example.com	2b4c3512e66cc3c23dbc2a147f7d700c2d54388ef5ebac9ae67bc14a371ab2f7	t	1971-03-15 04:05:05.588548	1995-05-23 12:16:33.094885
51	kolesnikernest@example.com	9f2588568b0db112132d684d8399f4b82ef33baed35cf66b4e20e941257efae8	t	1987-02-08 06:27:17.657555	2000-10-05 16:13:31.230511
52	ksawerykondej@example.com	70a674ab49cb843cb72071817fbfca3888f55d31338b7e0b49a0dcb45e0382cc	t	1997-11-30 13:20:23.203983	2012-03-25 22:34:14.102026
53	fsimon@example.com	459cf6f4ce9cc84b75eae003a242d377a31b02251dff7a1e7c950429f22a979c	t	1989-01-19 21:52:34.054785	2023-01-18 07:01:58.375023
54	stefan19@example.com	207d91217005045ff1dc67a7bf97541325fd27b1cd1c7f2ad6a111ed59fbed14	t	1995-07-07 11:13:35.681469	1972-01-28 10:15:25.092716
55	dkapcia@example.com	a3c799dff080b8111d58112a7e16242bc59150b595236f586e683c14e7861f9d	t	2018-07-20 01:10:40.306869	2010-07-03 14:33:17.768409
56	mirgajanina@example.net	ae52c51e99bfe8e4080939f4c00d822e0fd7efda57edd07ccb36029562430ae0	t	1993-04-28 18:35:02.671411	2012-04-02 08:20:10.683118
57	marcel73@example.com	ed60bfb267efd586047765259fee68dbd28d70586878c20c0dec8b6358194823	t	2011-09-12 18:40:18.72062	1976-06-24 16:47:06.747598
58	odoroba@example.org	a2b85e142a31a4d990a0a06e89eb41705cb10ecbd3aa7a3cd1ad9f2c3a9b3eea	t	1983-11-28 04:45:16.170773	1993-08-12 19:55:51.827276
59	awolos@example.com	21de26d4afbc498282cd450d3584abbc1714cdda31ce7e356cce626baffa2ef4	t	2012-08-09 12:08:30.797021	2016-07-08 17:26:42.420602
60	chlebdaernest@example.org	08c255e04cf43917fc2a1eaef7dade2261e47a76c5164c76886d349eac9388df	t	1981-11-01 05:41:23.201727	1978-03-20 08:04:50.213453
61	spychajkazimierz@example.org	2173febce47cbea799e83922bc2b61be6d7d542ef749d8eb8e5645a6862ee614	t	2015-09-17 11:14:21.482727	1989-03-25 06:20:47.506315
62	ksiezyksara@example.net	986bba1c96ed8e4348c561a20196ff31148c43eb2d931d8ce4e3093b410ae2a9	t	2005-05-12 11:25:01.532119	1979-11-17 20:47:29.806659
63	uwziatek@example.net	a559941ed419a3e6e9a76c0f69ee2f644824e216e252793af52457bbbf6b8958	t	2007-02-21 21:51:44.21747	2009-08-04 14:44:21.771423
64	kolochjanina@example.com	9c4ada24c5b8c551e8370b745957b3feb1b5c41526e4c658f618a1197267d352	t	2002-08-07 14:00:01.62594	1989-12-12 14:58:55.684494
65	aurelia14@example.net	67acd643e380600ba5094d7e6a03052f04b4120d2c6e8f329dfd245bf733aabc	t	2023-09-27 05:45:28.409708	2002-12-20 03:45:33.499761
66	tochal@example.net	f511d310f6e1594bbd27ac024c6fe1e5b276843d04e12fbdb4278ff2da02a427	t	1979-04-28 12:15:50.220919	1984-05-28 11:08:48.450285
67	jacek73@example.org	3795fa55e81919c4ede49bb6f6030d20b001676cca1e6efb69cd875378bbe732	t	2000-05-16 03:10:29.027498	2017-04-12 11:45:37.894368
68	ryznarfilip@example.com	f1afcc35be211a35deae6e06fa9e38c9d1fe619ace5aeac7ac170219508b8622	t	2016-09-14 13:43:14.75981	2000-06-18 12:48:39.104917
69	ryszardhandzel@example.org	68fcfd47d3c288fec3b71a037d0e95d35aee4bb6cf72b73bf305aefe4067f1c7	t	2013-07-24 13:31:24.548789	1974-10-02 02:27:39.516171
70	pacholikkaja@example.com	7f5f2108feb208f4a997b1e17088edf2807fb572189033303883d0e5a19df226	t	1977-09-10 10:58:52.651723	1978-05-21 08:45:55.235469
71	mieszko94@example.org	651f0baf02a8992f4f37bb41171ccbf2bd41fcd0bf16df305316a204ad50af74	t	1978-02-21 07:41:51.250506	1984-09-16 14:19:16.637964
72	dabrosjulian@example.com	a951a242c533333b12ca366db64731620983e04f133926e5a032c0b268e5b8ea	t	1971-09-20 22:03:14.418123	1974-11-13 08:02:31.711905
73	antoninagorka@example.net	b60c25edaadcdab56a6cba42031bcabb63b32858009ce23bd9852c24c1dfccd2	t	2004-03-28 19:18:40.693686	1976-03-09 12:00:35.311111
74	dariusz93@example.net	539eb5ac39f3553be63260b96d33c3d1a0f4975ce32fd1177a707fac351b79e2	t	2015-01-03 19:07:12.138621	1975-08-15 09:11:39.458215
75	malonleonard@example.com	ca985f23f1fef504805f63cb82b22fe5bc2daedad3c9fd239bf302924454c076	t	2016-01-27 00:36:01.369548	1990-05-23 19:51:21.232197
76	urszulalegowik@example.com	2c2558475d8395ff832774130804bf1d1e01b66de03a6cf027eb86049092b935	t	1991-04-14 21:21:33.649343	2007-02-28 04:53:57.432928
77	stanislaw68@example.org	62e9a485a1b18609846f947b264797f69175ea9b8bf5861c126cf4b0a0fd7477	t	2000-03-20 05:17:50.624273	2000-10-01 16:51:01.502329
78	jedrzej28@example.org	b8336fd012517ae690e0ee670690258609af33b089a0eca5b5044f6c46fecf05	t	2025-12-25 03:18:44.108099	2018-12-03 16:16:42.151272
79	npusz@example.org	e4235e0aa591159fb99940c3eb073313426be22bc13544bead67f03481c92820	t	2003-05-15 04:43:10.016173	1990-03-12 09:17:36.983823
80	rszalas@example.com	75e5cb3c901fd1461eba8128794c7e21c56e31b3348c8b42eccb3c5f07074f29	t	1999-11-02 00:57:29.175236	2025-04-18 22:49:58.029354
81	borkowiczdamian@example.org	a33207005c9d2e7c972902c557583610c0a24521f7edf9346296b8fae69a2a61	t	1984-04-25 12:54:17.934415	1972-10-13 17:09:49.789813
82	qpuch@example.org	d0d647bfae7c0728244add02799a1857bc883d7ff80bd06f5dfb505d9a178d78	t	2005-09-21 21:11:14.782543	2019-08-12 08:59:33.241524
83	mglazik@example.org	6ea7a0afe31baaa438ce5701230abd5c6907c91250a5419cd093b42e57bf294a	t	2000-11-24 15:35:50.52049	1976-07-14 03:21:24.041894
84	roksana08@example.com	83df5d188c85a0d1df6f011aa44d057d0ccb722583841fe392712660488e397f	t	2009-07-30 12:20:49.04838	1980-01-11 14:02:46.295772
85	uchomiuk@example.net	5db4d84b63aedeb26febd79dc6d42272016549b4a0c5f5ca5c04877331c334bd	t	2015-08-31 23:41:46.319157	2018-10-29 13:45:24.768753
86	ingazelazo@example.org	5da41e36176a1548f0d93c41715e204004f10b61cb71fd0ae7b108820ed9e0d1	t	1993-09-05 10:02:52.856871	1997-06-23 15:14:19.289899
87	kalina52@example.org	d2cfbaba6d079bc5515fc5196583b1c90aedad71a20e85ae32eaee2fedb0a4c4	t	2007-12-05 16:14:31.476804	2016-11-16 07:47:39.692699
88	kamilwiak@example.net	51466cf35bff936faff331329cb97a3f5418bb092b6d6a258342c445829b3e69	t	1984-06-16 19:06:45.582974	1994-12-31 00:24:09.279413
89	juliuszdrywa@example.org	37465a78b281f396ee1718019bfba63c44592ea5ac91956d6565d6154884f89b	t	2011-10-25 01:23:57.463088	1989-05-25 22:32:25.138985
90	brusaleksander@example.net	c2ed581683b864d2085eccbe4ae01e5e3c6c7cc3f683a04b19a07b83b9b111e8	t	1990-12-20 11:59:13.097464	2008-12-03 14:18:26.400045
91	drewnioksandra@example.com	a17df983a8e8e28f8e1f202dcc41896f0f4445a76ced7392659a3cce9d13d55d	t	1975-11-03 13:25:18.391384	1996-10-28 06:21:00.546031
92	nela30@example.net	f3a96ade93a3977771030cb622df41f9ccd80208f0606e2bb8b9cc12a3fd68e2	t	2024-10-26 23:55:28.471073	1980-10-07 08:06:39.250906
93	ceynowajuliusz@example.org	8230213d6bdb9067ebd5cda03fd6c8ecc6063ff10aa8fc39bbcd7435b18bdaf0	t	1970-10-30 09:48:49.277397	1970-06-25 19:56:45.054659
94	protasiukagnieszka@example.net	eae40e85f31bdb4b7c2cefb519b1b33f98ed35a0497b01724bdba23d28401c77	t	1992-12-28 19:33:37.494825	1992-07-05 22:35:58.644126
95	adriannakarwala@example.com	9e929f404834847641bab3db059aea36c087a6bb48c18b17b50134d50d96d576	t	1971-01-29 18:45:59.934425	1995-04-27 14:11:15.666138
96	kmaciejczuk@example.net	1b156cd16899cd6f8ded8c6ac86498da0ed30ee7dedc200341c60ae95f290a8a	t	2019-06-08 10:33:02.105819	1983-09-14 19:40:21.856398
97	drozdakornel@example.net	327cde3e316235d7a744671d218ee3ff25f7c4c00963429ddf6d43c6e1977db5	t	2014-06-10 11:39:01.797883	1974-09-10 04:32:11.80445
98	jeremipikor@example.com	83d9594bdd890923edf5e5347ad5f76770d32972f383ca817db721946684cc6d	t	1987-11-17 22:35:53.193041	2016-12-10 13:28:19.979291
99	damian32@example.org	4f7f1c64743cb57809bebcde1b74c400dc84aa909516e7894989c1b3b3994caf	t	1975-07-13 07:06:38.674625	1988-08-24 08:02:40.101028
100	sara63@example.com	84709a8f4a8b9bb3a5010650f75b0f1b8d5d58e4061895597a910cbe9c3f53bc	t	1999-02-09 05:03:59.931436	1987-02-19 02:36:48.405748
\.


--
-- Data for Name: user_emails; Type: TABLE DATA; Schema: public; Owner: leak_user
--

COPY public.user_emails (id, email, user_id, is_verified, created_at) FROM stdin;
1	ernest22@example.net	1	t	1990-12-01 01:57:01.52504
2	marcelinamotak@example.com	2	t	1972-07-19 22:40:47.228678
3	karaluscezary@example.com	3	t	1978-07-30 01:37:51.00056
4	dominiklato@example.org	4	t	2002-10-02 21:10:28.94395
5	kazimierznieroda@example.com	5	t	1974-12-09 04:24:35.574937
6	mszycabianka@example.org	6	t	2008-03-27 13:54:15.187036
7	alex87@example.net	7	t	1998-01-03 14:40:31.674494
8	kupidurablanka@example.org	8	t	1990-10-31 07:02:51.977722
9	uwiatrak@example.com	9	t	1971-09-07 06:13:13.756413
10	sara47@example.net	10	t	1987-12-16 07:23:22.852502
11	julian31@example.net	11	t	1986-06-19 07:40:20.885982
12	ganton@example.net	12	t	1982-02-19 20:00:33.186393
13	milosz85@example.org	13	t	1995-10-10 09:35:15.168644
14	jczesak@example.com	14	t	1985-09-05 18:05:03.814531
15	fabian35@example.org	15	t	1979-01-31 10:53:43.598701
16	adam16@example.org	16	t	2022-08-23 03:12:10.321769
17	dorota58@example.net	17	t	1974-08-06 04:13:47.74607
18	franciszek64@example.org	18	t	1975-03-22 17:19:35.492669
19	borunandrzej@example.com	19	t	1997-03-30 12:35:57.345021
20	andrzejwasiewicz@example.com	20	t	2001-04-24 11:01:26.704297
21	stryka@example.com	21	t	2012-09-26 02:11:44.908025
22	iwosoroko@example.org	22	t	1990-01-31 07:08:02.224672
23	qbulak@example.com	23	t	2001-09-26 19:35:14.645151
24	natasza92@example.org	24	t	2004-11-30 22:14:10.058025
25	sylwialegowik@example.net	25	t	2016-09-14 20:22:55.535996
26	sztabarobert@example.net	26	t	1999-03-06 15:31:50.663122
27	hmiszkiewicz@example.org	27	t	2004-12-26 21:05:18.669984
28	marianna67@example.org	28	t	1997-10-01 01:04:39.108328
29	ciukkalina@example.net	29	t	2007-08-15 02:26:33.691432
30	cwykret@example.com	30	t	2003-07-23 08:33:31.766419
31	penarjerzy@example.com	31	t	1986-01-28 09:10:16.401105
32	wrzesniakarkadiusz@example.org	32	t	2010-12-08 12:13:48.784748
33	fmaly@example.org	33	t	1983-04-26 13:38:36.950104
34	skowyramalwina@example.org	34	t	2012-11-17 18:55:23.415454
35	fryderyk00@example.org	35	t	1993-03-06 14:28:40.746964
36	gaja56@example.org	36	t	2025-01-06 18:00:23.447592
37	marianna28@example.net	37	t	1983-05-13 01:32:30.45644
38	cmateusiak@example.net	38	t	1992-01-02 08:12:32.625903
39	lbruzda@example.com	39	t	1982-03-29 10:37:55.530191
40	upiersa@example.com	40	t	1974-07-07 21:57:56.205956
41	tymoteuszsarosiek@example.com	41	t	1973-02-26 04:58:23.182428
42	kurcernest@example.org	42	t	1994-10-03 12:53:59.294699
43	igor14@example.com	43	t	2013-08-30 07:38:07.16083
44	malwina42@example.net	44	t	2006-09-25 12:39:41.47537
45	angelikagolus@example.org	45	t	1984-09-30 21:12:30.978317
46	maks82@example.com	46	t	1976-04-04 16:45:48.334426
47	zzakiewicz@example.com	47	t	2018-12-29 10:22:00.029376
48	nbuksa@example.org	48	t	1984-09-07 19:12:52.913149
49	tymoteuszleoniak@example.com	49	t	1997-06-01 21:08:34.456153
50	xkierat@example.org	50	t	1990-01-20 03:03:18.043033
51	olaf06@example.net	51	t	2011-07-27 18:03:07.665167
52	ada49@example.com	52	t	2000-04-02 22:27:02.368849
53	albertgral@example.org	53	t	2008-11-15 14:35:43.095144
54	roza66@example.net	54	t	2015-11-28 13:31:10.499138
55	iwokohnke@example.com	55	t	1984-08-11 13:39:21.31081
56	norbert32@example.net	56	t	1978-07-25 19:28:35.37063
57	olgierd04@example.net	57	t	1974-08-06 17:39:55.276439
58	szybajulianna@example.com	58	t	2009-08-06 13:08:57.485302
59	soniablaziak@example.org	59	t	2020-02-28 13:27:19.834588
60	brunokurbiel@example.com	60	t	1976-09-22 21:41:14.670203
61	semikapolonia@example.com	61	t	1973-12-22 18:08:28.989174
62	kotlarekroksana@example.com	62	t	1980-09-01 01:47:40.972541
63	cholodygrzegorz@example.com	63	t	2015-09-24 06:58:14.066435
64	blanka57@example.org	64	t	2022-11-14 20:56:50.557328
65	niewolakacper@example.net	65	t	1993-03-03 14:56:47.277513
66	naumiukoliwier@example.net	66	t	1998-11-03 06:37:26.652727
67	ernest74@example.net	67	t	1970-02-14 08:30:19.018666
68	nciochon@example.net	68	t	2008-04-05 04:19:44.924352
69	mateuszzelasko@example.org	69	t	2015-05-12 16:35:10.405329
70	mieszko27@example.net	70	t	2025-02-08 18:09:12.788328
71	xbladek@example.org	71	t	1988-04-21 21:40:22.766595
72	gborysewicz@example.org	72	t	2015-12-18 21:05:22.205585
73	monikalodyga@example.com	73	t	2009-07-22 01:30:54.180473
74	kalinajaniga@example.com	74	t	1981-11-01 17:04:18.927315
75	nataniel98@example.net	75	t	1983-04-28 20:15:55.05968
76	inga79@example.org	76	t	2013-10-24 01:43:19.760337
77	sandra08@example.net	77	t	2024-01-27 18:02:38.521161
78	sylwiabicz@example.com	78	t	1979-10-12 01:56:35.295109
79	cyprianferdyn@example.com	79	t	2020-07-15 18:08:08.762328
80	pituraoliwier@example.org	80	t	2013-01-20 03:12:03.391937
81	tkomperda@example.org	81	t	1992-08-09 09:04:04.796087
82	lukowiaktymon@example.net	82	t	2015-06-30 19:24:45.288098
83	ksawerydoktor@example.org	83	t	2000-07-23 16:18:54.420532
84	aleks55@example.org	84	t	2011-10-31 02:38:45.913317
85	biankamorys@example.net	85	t	1980-02-15 21:54:16.830267
86	nela86@example.net	86	t	2014-12-05 15:48:12.561584
87	vtruchan@example.net	87	t	2014-07-14 17:44:11.209296
88	bryzekjustyna@example.org	88	t	1982-06-04 04:33:29.297828
89	hubert20@example.net	89	t	1982-09-08 22:42:56.449705
90	paczoseryk@example.net	90	t	2000-08-07 15:51:52.37515
91	raganjulian@example.net	91	t	2014-08-01 00:08:43.614474
92	zmalcherek@example.org	92	t	1989-08-17 00:55:05.845012
93	pryksonia@example.com	93	t	1998-04-03 04:53:01.672499
94	dorota51@example.net	94	t	1980-04-05 21:12:30.741108
95	pdomino@example.org	95	t	2017-02-11 02:13:18.216413
96	hoslizlo@example.net	96	t	1983-02-07 17:21:41.171847
97	bastekcezary@example.net	97	t	2019-01-19 12:37:31.16362
98	kaja41@example.com	98	t	1992-05-08 00:34:01.387465
99	tola33@example.org	99	t	2023-07-24 07:19:25.493423
100	kmakiela@example.net	100	t	1989-08-06 07:56:29.630795
\.


--
-- Name: email_breach_matches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leak_user
--

SELECT pg_catalog.setval('public.email_breach_matches_id_seq', 1, false);


--
-- Name: incident_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leak_user
--

SELECT pg_catalog.setval('public.incident_reports_id_seq', 1, false);


--
-- Name: login_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leak_user
--

SELECT pg_catalog.setval('public.login_history_id_seq', 1, false);


--
-- Name: user_emails_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leak_user
--

SELECT pg_catalog.setval('public.user_emails_id_seq', 1, false);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leak_user
--

SELECT pg_catalog.setval('public.user_id_seq', 1, false);


--
-- Name: user_emails PK_3ef6c4be97ba94ea3ba65362ad0; Type: CONSTRAINT; Schema: public; Owner: leak_user
--

ALTER TABLE ONLY public.user_emails
    ADD CONSTRAINT "PK_3ef6c4be97ba94ea3ba65362ad0" PRIMARY KEY (id);


--
-- Name: incident_reports PK_8b924dea33e3dd1ef1bbac02ad6; Type: CONSTRAINT; Schema: public; Owner: leak_user
--

ALTER TABLE ONLY public.incident_reports
    ADD CONSTRAINT "PK_8b924dea33e3dd1ef1bbac02ad6" PRIMARY KEY (id);


--
-- Name: email_breach_matches PK_b72d4a213790ea4816612dd764d; Type: CONSTRAINT; Schema: public; Owner: leak_user
--

ALTER TABLE ONLY public.email_breach_matches
    ADD CONSTRAINT "PK_b72d4a213790ea4816612dd764d" PRIMARY KEY (id);


--
-- Name: user PK_cace4a159ff9f2512dd42373760; Type: CONSTRAINT; Schema: public; Owner: leak_user
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT "PK_cace4a159ff9f2512dd42373760" PRIMARY KEY (id);


--
-- Name: login_history PK_fe377f36d49c39547cb6b9f0727; Type: CONSTRAINT; Schema: public; Owner: leak_user
--

ALTER TABLE ONLY public.login_history
    ADD CONSTRAINT "PK_fe377f36d49c39547cb6b9f0727" PRIMARY KEY (id);


--
-- Name: user_emails FK_2e88b95787b903d46ab3cc3eb91; Type: FK CONSTRAINT; Schema: public; Owner: leak_user
--

ALTER TABLE ONLY public.user_emails
    ADD CONSTRAINT "FK_2e88b95787b903d46ab3cc3eb91" FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: incident_reports FK_a29892e480fe97776c01f04b9dd; Type: FK CONSTRAINT; Schema: public; Owner: leak_user
--

ALTER TABLE ONLY public.incident_reports
    ADD CONSTRAINT "FK_a29892e480fe97776c01f04b9dd" FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: login_history FK_ad9ce49cb73c0b33746a56b6bd1; Type: FK CONSTRAINT; Schema: public; Owner: leak_user
--

ALTER TABLE ONLY public.login_history
    ADD CONSTRAINT "FK_ad9ce49cb73c0b33746a56b6bd1" FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO leak_user;


--
-- PostgreSQL database dump complete
--

\unrestrict Ns7FshaRNe3qbRMUFTLHJoTr5p0Zum4kgGIsO0IbByafbKiqQfSc51UzM1nF3hm

